# Chapter 5 frozen-model performance and negative-control audit

PASS for the reported ROC-AUC and descriptive negative-control finding. No numerical revision is needed for these Chapter 5 statements.

The original ISIC evaluation file contains 1,200 rows (100 images, four conditions, three methods). Baseline predictions and labels agree exactly across methods for each image. Collapsing repeated records to 100 unique images yields 50 melanoma and 50 non-melanoma images and ROC-AUC 0.4164, which rounds to the dissertation’s 0.416. This verifies a saved-prediction calculation, not fresh inference or clinical performance validation.

All 3,600 control tasks are present and unique: 1,200 each for random_uniform, spatial_shuffle and permuted_mask. Their real-map metrics match the original evaluation file exactly. Reproduced all 18 image-cluster bootstrap rows with 2,000 draws per outcome and seed 20260922: means, confidence intervals, sign probabilities and BH q-values. Maximum numeric export discrepancy 9.72e-17. The deterministic permutation of all 100 mask identifiers also reproduces exactly, with no self-pairings.

Mixed metric-specific results agree with Chapter 5. Real maps have negative deletion-AUC advantage against random and shuffled maps, positive insertion-AUC advantage, and differing localization results. Soft-IoU advantage is negative against random-uniform maps and positive against spatial shuffling. No claim of uniformly better explanation quality or robust negative-control superiority is warranted.

As in the PH2 analysis, the negative-control column centered_bootstrap_p actually stores a two-sided bootstrap sign probability. It is not the centered-bootstrap null approximation used for the ISIC association analysis. BH correction here is over 18 outcomes. Preserve this distinction in methods documentation.

Scope remaining: no model inference, raw control-map creation, raw pixel-to-outcome calculation, or clinical validation was rerun. The existing protocol-sensitivity bundle also contains model/input probability-parity diagnostics; numerical reproducibility of downstream inference does not independently establish cross-runtime prediction parity. A later reproducibility review should retain that source limitation rather than claim exact fresh-inference equivalence.

This completes the saved-data checks of the ROC-AUC and negative-control claims requested in this step. It does not certify all experiment generation provenance or close the principal corpus’s remaining attribution lineage questions.

Run reproduce_audit.py with numpy pandas scikit-learn installed. Inputs, reproducible baseline cohort predictions, bootstrap exports, machine-readable findings and hashes are included. The large original ISIC ZIP is represented by its hash plus the exact compact files extracted for this audit.
