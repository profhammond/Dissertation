from pathlib import Path
import json,zipfile,hashlib
import numpy as np,pandas as pd
from sklearn.metrics import roc_auc_score
ROOT=Path(__file__).resolve().parent;SRC=ROOT/'inputs'
with zipfile.ZipFile(SRC/'edi_faithfulness_localization_negative_control_audit_v1_outputs.zip') as z:z.extractall(ROOT/'extracted')
N=ROOT/'extracted';d=pd.read_csv(SRC/'evaluation_results.csv.gz');ControlDF=pd.read_csv(N/'negative_control_results.csv.gz')
assert len(d)==1200 and d.image_id.nunique()==100 and not d.duplicated(['condition','attribution_method','image_id']).any()
g=d[d.condition.eq('baseline')]
assert g.groupby('image_id').original_probability.nunique().eq(1).all() and g.groupby('image_id').label.nunique().eq(1).all()
v=g.groupby('image_id').agg(label=('label','first'),probability=('original_probability','first'))
assert v.label.value_counts().to_dict()=={0:50,1:50} or v.label.value_counts().to_dict()=={1:50,0:50}
auc=float(roc_auc_score(v.label,v.probability));assert abs(auc-.4164)<1e-12
v.to_csv(ROOT/'verified_baseline_cohort_predictions.csv')
assert len(ControlDF)==3600 and not ControlDF.duplicated(['condition','attribution_method','image_id','control_type']).any()
assert ControlDF.groupby('control_type').size().eq(1200).all()
metrics=['deletion_auc','insertion_auc','deletion_confidence_drop','energy_inside_lesion','pointing_hit','soft_iou','top10_iou']
reference=d[['condition','attribution_method','image_id']+metrics]
m=ControlDF.merge(reference,on=['condition','attribution_method','image_id'],validate='many_to_one')
real_error=max(float(abs(m['real_'+x]-m[x]).max()) for x in metrics);assert real_error<1e-12
nb=json.loads((SRC/'EDI_Faithfulness_and_Localization_Negative_Control_Audit_v1.ipynb').read_text());TABLES=ROOT;SEED=20260922;BOOTSTRAP_REPS=2000
outputs={}
def atomic_csv(p,df):outputs[p.name]=df;df.to_csv(p,index=False)
def display(*args):pass
exec(''.join(nb['cells'][7]['source']))
old=pd.read_csv(N/'tables/table_negative_control_cluster_bootstrap.csv');new=InferenceDF
assert old.shape==new.shape
nums=new.select_dtypes(include='number').columns
err=float(abs(old[nums]-new[nums]).max().max());assert err<1e-12
assert np.isfinite(ControlDF[['control_'+x for x in metrics[3:]]]).all().all()
perm=pd.read_csv(N/'audits/mask_derangement.csv')
assert len(perm)==100 and perm.image_id.nunique()==100 and perm.permuted_mask_image_id.nunique()==100 and perm.image_id.ne(perm.permuted_mask_image_id).all()
ids=sorted(d.image_id.astype(str).unique());rng=np.random.default_rng(SEED);shuffled=ids.copy()
while True:
 rng.shuffle(shuffled)
 if all(a!=b for a,b in zip(ids,shuffled)):break
expected=pd.DataFrame({'image_id':ids,'permuted_mask_image_id':shuffled});assert expected.equals(perm[expected.columns])
report=dict(baseline_ROC_AUC=auc,baseline_unique_images=100,class_counts={'melanoma':50,'non_melanoma':50},negative_control_tasks=3600,negative_control_types=sorted(ControlDF.control_type.unique().tolist()),mask_derangement_reproduced=True,real_metrics_maximum_source_difference=real_error,bootstrap_rows=18,bootstrap_replicates=2000,bootstrap_seed=SEED,bootstrap_export_maximum_difference=err,scope='Saved predictions and downstream negative-control analysis reproduced. No fresh inference, model training, raw control-map generation or outcome computation from raw pixels.',methodology='Negative controls use two-sided bootstrap sign probabilities; centered_bootstrap_p column name is misleading. BH adjustment covers 18 outcomes.',source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in SRC.iterdir() if p.is_file()})
(ROOT/'audit_results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
