# External cohort record recovery review — 2026-10-05

All 312 bundle checksum entries and all 309 manifest export hashes passed. No recovery issues were recorded. Source hashes refer to original Drive records; exported CSVs were reserialized or subsetted and have distinct hashes. BreakHis original EDI source hash matches the separately supplied CSV.

Five domains each contain a nested six-method table of 5,760 comparisons on 40 images, 28 prediction exports and 28 run configurations. All configuration run IDs match their directory names. Comparison keys have no duplicates. Maximum EDI formula discrepancy is 7.500012e-11, consistent with saved decimal precision.

| Domain | Training | Validation | Test | Test negatives / positives |
|---|---:|---:|---:|---:|
| BreakHis |37|2|1|0 / 1|
| Fundus |32|4|4|0 / 4|
| CXR |36|1|3|0 / 3|
| ChestXray14 |33|3|4|0 / 4|
| SIPaKMeD |22|10|8|3 / 5|

These counts refer to the nested six-method EDI cohorts, not overall dataset splits. CXR and ChestXray14 exports include additional IDs from separate 960-row EDI tables; those were excluded from this join. Their results must remain separate.

## Available relationship records

Baseline and comparison test predictions joined successfully by recorded experiment and exact image ID: 2,880 method-level rows across 20 domain-specific test images. Labels agree between paired prediction records and probabilities are finite in [0,1]. Repeated methods, transformations and resolutions do not create additional independent test images. Exported probabilities and correctness indicators are retained in provisional_test_only_prediction_edi_joins.csv; no significance testing was performed because support is extremely small.

Exact ID joins and matching configuration names do not verify image bytes, transformation implementations, model hashes, attribution targets or historical map-generating identities. The joined table is provisional and must not be presented as provenance-certified evidence. Recorded configurations describe separately named preprocessing runs; these are not established fixed-model comparisons.

## Consequences for the research question

The historical EDI tables characterize map disagreement on balanced 40-image cohorts, most of whose members are training images. They do not provide a sufficiently sized held-out joint evaluation of drift and classification. Four domains have no negative-class test images within this cohort; therefore specificity, ROC-AUC and a between-class error comparison cannot be estimated from these subsets. One BreakHis image cannot support an image-level correlation, regardless of repeated conditions.

Existing full test predictions remain useful for classification performance after provenance and split verification, but they lack attribution comparisons for most test images. Recovering predictions on training images could support an explicitly in-sample descriptive analysis, not repair this held-out limitation.

Recommended next experiment: select a new locked cohort from the archived test splits, verify exact images and labels plus leakage/group constraints, and generate attribution comparisons with verified saved models and transformation implementations. Keep it a separate prospective dataset. Begin with one resolution and two prespecified preprocessing conditions; select cohort size after model/path feasibility review. Domain class meanings differ (e.g., ChestXray14 Pneumonia versus No Finding), so analyze domains separately before any synthesis. A balanced evaluation cohort does not establish balanced training.

Before GPU generation, recover the original training/attribution producer notebooks and verify saved model loading, preprocessing parity, targets and image lineage. No retraining requirement is established by this audit, and no generation notebook should guess those implementations.
