from pathlib import Path
import json,zipfile,hashlib
import numpy as np,pandas as pd
from scipy.stats import rankdata,spearmanr
ROOT=Path(__file__).resolve().parent;SRC=ROOT/'inputs'
for p in SRC.glob('*.zip'):
 with zipfile.ZipFile(p) as z:z.extractall(ROOT/'extracted'/p.stem)
E=ROOT/'extracted';I=E/'edi_fixed_model_faithfulness_localization_isic100_r224_v1_sensitivity_v1';H=E/'edi_ph2_external_localization_replication_v1_compact_audit_bundle/edi_ph2_external_localization_replication_v1';P=E/'faithfulness_perturbation_protocol_sensitivity_audit_v1_compact_bundle (1)'
i=pd.read_csv(I/'analysis_manifest.csv');h=pd.read_csv(H/'paired_comparisons.csv.gz');p=pd.read_csv(P/'tables/paired_protocol_deterioration.csv.gz')
def bh(v):
 v=np.asarray(v);o=np.argsort(v);q=np.empty(len(v));q[o]=np.minimum(1,np.minimum.accumulate((v[o]*len(v)/np.arange(1,len(v)+1))[::-1])[::-1]);return q
for name,d,n,images in [('ISIC',i,900,100),('PH2',h,1800,200)]:
 assert len(d)==n and d.image_id.nunique()==images and not d.duplicated(['condition','attribution_method','image_id']).any()
 err=float(abs((((1-d.pearson_corr)/2)+(1-d.ssim))/2-d.edi_primary).max());assert err<1e-12
 for metric in ['energy_inside_lesion','pointing_hit','soft_iou','top10_iou']:
  assert np.allclose(d['deterioration_'+metric],d['baseline_'+metric]-d['condition_'+metric],atol=1e-12,rtol=0)
# Vectorized ranks reproduce the same image-cluster draws and Spearman statistics.
def take_indices(g,rng):
 ids=g.image_id.unique();idx=[np.flatnonzero(g.image_id.to_numpy()==x) for x in ids];assert len({len(x) for x in idx})==1
 sampled=rng.choice(ids,size=(2000,len(ids)),replace=True);lut={x:j for j,x in enumerate(ids)}
 nums=np.array([[lut[x] for x in row] for row in sampled]);return np.asarray(idx)[nums].reshape(2000,-1)
def bootstrap(g,metric,take):
 x=g.edi_primary.to_numpy();y=g[metric].to_numpy();point=float(spearmanr(x,y).statistic);vals=[]
 for start in range(0,2000,100):
  t=take[start:start+100];a=rankdata(x[t],axis=1);b=rankdata(y[t],axis=1);a-=a.mean(axis=1,keepdims=True);b-=b.mean(axis=1,keepdims=True)
  vals.extend(np.sum(a*b,axis=1)/np.sqrt(np.sum(a*a,axis=1)*np.sum(b*b,axis=1)))
 return point,np.asarray(vals)
checks=[];new=[]
old=pd.read_csv(I/'tables/table_stratified_cluster_bootstrap.csv');primary=old.query("family=='pooled' and cohort=='complete'")
take=take_indices(i,np.random.default_rng(20260913))
for r in primary.itertuples():
 obs,b=bootstrap(i,r.metric,take);lo,hi=np.quantile(b,[.025,.975]);pv=(1+sum(abs(b-obs)>=abs(obs)))/2001
 err=max(abs(obs-r.spearman_rho),abs(lo-r.ci_low),abs(hi-r.ci_high),abs(pv-r.centered_bootstrap_p));assert err<1e-12
 new.append(dict(dataset='ISIC',metric=r.metric,rho=obs,ci_low=lo,ci_high=hi,p=pv))
checks.append(dict(check='ISIC seven complete-cohort estimates, CIs and centered p-values',passed=True))
assert np.allclose(bh(old.centered_bootstrap_p),old.bh_q,atol=1e-12,rtol=0)
oldh=pd.read_csv(H/'tables/table_ph2_clustered_associations.csv');rng=np.random.default_rng(20260922);phrows=[]
metrics=['deterioration_energy_inside_lesion','deterioration_pointing_hit','deterioration_soft_iou','deterioration_top10_iou']
for family,name,g in [('pooled','all',h)]+[('method',m,h[h.attribution_method.eq(m)]) for m in ['gradcam','gradcampp','eigencam']]:
 for m in metrics:
  take=take_indices(g,rng);obs,b=bootstrap(g,m,take);lo,hi=np.quantile(b,[.025,.975]);pv=min(1.,max(2*min(np.mean(b<=0),np.mean(b>=0)),1/2001))
  r=oldh.query('family==@family and cohort==@name and metric==@m').iloc[0]
  err=max(abs(obs-r.spearman_rho),abs(lo-r.ci_low),abs(hi-r.ci_high),abs(pv-r.centered_bootstrap_p));assert err<1e-12
  phrows.append(dict(dataset='PH2',method=name,metric=m,rho=obs,ci_low=lo,ci_high=hi,p=pv))
assert np.allclose(bh([r['p'] for r in phrows]),oldh.bh_q,atol=1e-12,rtol=0)
new.extend(phrows);checks.append(dict(check='PH2 all 16 estimates, CIs, sign p-values and BH q-values',passed=True))
olds=pd.read_csv(P/'tables/table_protocol_sensitivity_cluster_bootstrap.csv');rng=np.random.default_rng(20260923);prows=[]
for (sub,steps),g in p.groupby(['substrate','steps']):
 take=take_indices(g,rng);obs,b=bootstrap(g,'deterioration_deletion_auc',take);lo,hi=np.quantile(b,[.025,.975]);pv=min(1.,2*min(np.mean(b<=0),np.mean(b>=0)))
 r=olds.query('substrate==@sub and steps==@steps').iloc[0]
 assert max(abs(obs-r.spearman_rho),abs(lo-r.ci_low),abs(hi-r.ci_high),abs(pv-r.bootstrap_p))<1e-12
 prows.append(dict(substrate=sub,steps=int(steps),rho=obs,ci_low=lo,ci_high=hi,p=pv))
assert np.allclose(bh([r['p'] for r in prows]),olds.bh_q,atol=1e-12,rtol=0)
assert ((olds.ci_low<0)&(olds.ci_high>0)).all()
checks.append(dict(check='All nine deletion protocols: estimates, CIs, sign p-values and BH q-values',passed=True))
pd.DataFrame(new).to_csv(ROOT/'reproduced_associations.csv',index=False);pd.DataFrame(prows).to_csv(ROOT/'reproduced_protocol_associations.csv',index=False)
report=dict(checks=checks,ISIC_rows=900,PH2_rows=1800,bootstrap_replicates=2000,ISIC_BH_scope=len(old),PH2_BH_scope=len(oldh),protocol_BH_scope=len(olds),methodology_note='ISIC uses centered-bootstrap p-values. PH2 and protocol sensitivity use two-sided bootstrap sign probabilities; PH2 column is misleadingly named centered_bootstrap_p. These procedures are not identical.',scope='Saved comparisons and downstream inference reproduced. Map generation, quality outcomes from pixels, raw predictions and frozen-model ROC-AUC not independently reproduced.',source_sha256={x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in SRC.iterdir() if x.is_file()})
(ROOT/'audit_results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
