# Chapter 5 fixed-model association and protocol audit — 2026-10-03

PASS for the reported associations, confidence intervals, adjusted q-values, and nine-protocol sensitivity statement. This is a partial audit of the fixed-model section; negative controls and the reported frozen-model ROC-AUC 0.416 remain to be checked independently.

ISIC: 900 comparisons, 100 images. Reproduced all seven complete-cohort estimates, 2,000-replicate image-cluster bootstrap confidence intervals, and centered-bootstrap p-values using seed 20260913 (source base seed 20260912 plus cohort number 1). The adjusted q-values reproduce from all 154 exported p-values; the other 21 cohorts’ bootstrap p-values were not independently regenerated here.
- EDI versus deletion-AUC deterioration: rho 0.018122, CI [-0.083917, 0.118166], q 0.997951.
- EDI versus soft-IoU deterioration: rho -0.026926, CI [-0.143568, 0.084160], q 0.997951.

PH2: 1,800 comparisons, 200 images. Reproduced all sixteen pooled/method-specific associations, confidence intervals, bootstrap sign probabilities and BH q-values, seed 20260922. Pooled soft-IoU rho 0.105250, CI [0.020439, 0.181300], q 0.016. The three method-specific rho values agree with Chapter 5 rounding (-0.304, -0.009, 0.690).

Deletion protocol sensitivity: independently reproduced all nine 2,000-replicate protocol estimates, intervals, bootstrap sign probabilities and BH q-values, seed 20260923. All confidence intervals include zero and rho ranges round to [-0.030, 0.020], agreeing with Chapter 5.

Verified comparison key uniqueness, cohort sizes, EDI formula, and the deterioration direction (baseline minus transformed localization quality) in ISIC and PH2. This verifies saved metrics and inference, not quality-outcome generation from raw pixels, attribution generation, fresh model inference or raw prediction ROC-AUC.

Methodological distinction to retain: ISIC uses a centered-bootstrap null approximation. PH2 and protocol sensitivity use two-sided bootstrap sign probabilities. The PH2 column is misleadingly named centered_bootstrap_p although its code computes the sign probability. Numerical reproduction does not make these testing procedures equivalent. Their BH correction families also differ: ISIC 154, PH2 16, protocols nine. Do not present q-values as a single common cross-cohort testing family. Current Chapter 5 does not explicitly claim identical testing procedures.

Optional methods clarification (copy/paste LaTeX):
The ISIC sensitivity analysis used a centered image-cluster bootstrap approximation for testing associations, whereas the PH2 replication and perturbation-protocol audit used two-sided bootstrap sign probabilities. Benjamini--Hochberg adjustments were applied separately within each analysis family. The resulting adjusted values therefore describe their respective analysis procedures and are not a single cross-cohort multiplicity correction.

No numerical revision is required for these Chapter 5 association statements. Next: recover/check frozen-model cohort predictions and negative-control evidence.

Run reproduce_audit.py with numpy pandas scipy installed. Vectorized rank calculations preserve source cluster draws and reproduce Spearman correlations. Original inputs, source SHA-256 hashes, reproduced outputs and machine-readable findings are included; existing experiments remain untouched.
