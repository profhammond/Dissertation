# Chapter 5 matched-initialization provenance audit v2

Numerical results and completion-record evidence PASS. Supersedes v1’s missing-completion-record finding.

All six displayed means, four difference statements, and Grad-CAM ratios (2.74 and 2.82) reproduce from the saved 2,160-row comparison file. All 27 planned pair identifiers and condition/seed combinations reproduce from the notebook algorithm. No duplicate comparison keys; 40 images per pair/method; finite required metrics; primary EDI formula error at most 2.22e-16.

All 720 diagnostic JSON records report valid, nonconstant maps with no nonfinite map pixels. Fallback counts match: Grad-CAM 44, Grad-CAM++ 24, total 68. Every comparison endpoint has corresponding diagnostic metadata.

The nine newly uploaded DONE records cover baseline, dullrazor, telea for seeds 42, 1337, 2026 exactly once. Initialization digests are valid nonempty SHA-256 strings, equal across conditions within each seed and distinct across seeds. Completion timestamps and recorded classification metrics are present and valid. Conditions are identified from JSON contents rather than uploaded filenames.

The recovered notebook computes the digest over initial model weights converted to float32, copies the same initial weights to each condition within a seed, verifies the assigned weights, and writes the digest to the completion record. This audit verifies the saved records and code; it does not independently recompute digests from initial checkpoint arrays or reproduce model training. Classification metrics in DONE records are recorded outcomes, not independently recomputed from predictions here. Map arrays are absent from these diagnostic inputs, so map-to-metric reproduction remains outside this audit.

No numerical revision or retraining is indicated for the Chapter 5 matched-initialization section. This pilot remains separate from the principal corpus; descriptive contrasts do not establish statistical significance or causal fractions.

Run reproduce_audit.py with pandas, numpy, pyarrow installed. Original inputs, hashes, reproduced means/contrasts, model completion inventory, and findings are included.
