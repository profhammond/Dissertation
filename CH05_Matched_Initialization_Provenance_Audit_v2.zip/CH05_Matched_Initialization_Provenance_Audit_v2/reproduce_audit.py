from pathlib import Path
import json,hashlib,zipfile
import pandas as pd
import numpy as np
root=Path(__file__).resolve().parent
src=root/'inputs'
d=pd.read_parquet(next(src.glob('*.parquet')))
nb=json.loads(next(src.glob('*.ipynb')).read_text())
conditions=['baseline','dullrazor','telea']; seeds=[42,1337,2026]
pairs=[]
for c in conditions:
 for i,a in enumerate(seeds):
  for b in seeds[i+1:]:pairs.append(dict(comparison_type='within_condition_cross_seed',condition_a=c,seed_a=a,condition_b=c,seed_b=b))
for c in conditions[1:]:
 for a in seeds:pairs.append(dict(comparison_type='baseline_preprocess_matched_seed',condition_a='baseline',seed_a=a,condition_b=c,seed_b=a))
 for a in seeds:
  for b in seeds:
   if a!=b:pairs.append(dict(comparison_type='baseline_preprocess_cross_seed',condition_a='baseline',seed_a=a,condition_b=c,seed_b=b))
for p in pairs:p['pair_id']=hashlib.sha256(json.dumps(p,sort_keys=True,default=str).encode()).hexdigest()[:20]
plan=pd.DataFrame(pairs);cols=list(plan.columns)
assert d[cols].drop_duplicates().sort_values('pair_id').reset_index(drop=True).equals(plan.sort_values('pair_id').reset_index(drop=True))
assert len(d)==2160 and d.image_id.nunique()==40
assert d.groupby(['pair_id','attribution_method']).size().eq(40).all()
assert d.duplicated(['pair_id','attribution_method','image_id']).sum()==0
assert np.isfinite(d[['pearson_corr','ssim','edi_primary']]).all().all()
err=float(abs((((1-d.pearson_corr)/2)+(1-d.ssim))/2-d.edi_primary).max());assert err<1e-12
summary=d.groupby(['comparison_type','condition_a','condition_b','attribution_method']).edi_primary.agg(['size','mean']).reset_index()
summary.to_csv(root/'reproduced_means.csv',index=False)
baseline=d.query("comparison_type=='within_condition_cross_seed' and condition_a=='baseline'").groupby('attribution_method').edi_primary.mean()
matched=d.query("comparison_type=='baseline_preprocess_matched_seed'").groupby(['condition_b','attribution_method']).edi_primary.mean().rename('matched_mean').reset_index()
matched['baseline_mean']=matched.attribution_method.map(baseline)
matched['difference']=matched.matched_mean-matched.baseline_mean
matched['ratio']=matched.matched_mean/matched.baseline_mean
matched.to_csv(root/'reproduced_contrasts.csv',index=False)
assert baseline.round(3).to_dict()=={'gradcam':.091,'gradcampp':.731}
assert matched.matched_mean.round(3).tolist()==[.250,.685,.257,.737]
assert matched.difference.round(3).tolist()==[.159,-.046,.166,.006]
assert matched.query("attribution_method=='gradcam'").ratio.round(2).tolist()==[2.74,2.82]
records=[]
with zipfile.ZipFile(next(src.glob('*.zip'))) as z:
 for n in z.namelist():
  if n.endswith('.json'):records.append(json.loads(z.read(n)))
diag=pd.DataFrame(records)
assert len(diag)==720 and diag.valid_map.all() and not diag.map_is_constant.any() and diag.map_nonfinite_count.eq(0).all()
assert diag.duplicated(['condition','seed','method','image_id']).sum()==0
counts=diag.groupby('method').used_signed_fallback.sum().astype(int).to_dict();assert counts=={'gradcam':44,'gradcampp':24}
# Both endpoints must have a diagnostic with the corresponding model/image/method.
keys=set(diag[['condition','seed','method','image_id']].itertuples(index=False,name=None))
for row in d.itertuples(index=False):
 for endpoint in ('a','b'):
  assert (getattr(row,'condition_'+endpoint),getattr(row,'seed_'+endpoint),row.attribution_method,row.image_id) in keys
report={'comparison_rows':len(d),'image_clusters':d.image_id.nunique(),'planned_pairs_reproduced':len(plan),'duplicate_comparison_keys':0,'formula_maximum_error':err,'diagnostic_records':len(diag),'all_diagnostics_valid_nonconstant_finite':True,'signed_fallback_maps_by_method':counts,'all_comparison_endpoints_have_diagnostics':True,'dissertation_displayed_means_and_contrasts_match':True,'initialization_digest_evidence':'Notebook output reports one digest per seed; original model DONE.json files absent from recovered evidence. Not independently verified.','scope':'Analysis of saved comparison records and diagnostic metadata; no independent model training, map generation, or map-to-metric reproduction.','source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in src.iterdir() if p.is_file()}}
(root/'audit_results.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2));print(matched.to_string(index=False))

completion=[]
for p in sorted(src.glob('DONE_*.json')):
 r=json.loads(p.read_text());r['source_file']=p.name;completion.append(r)
cd=pd.DataFrame(completion)
assert len(cd)==9 and not cd.duplicated(['condition','seed']).any()
assert set(zip(cd.condition,cd.seed))=={(c,s) for c in conditions for s in seeds}
assert cd.groupby('seed').initialization_digest.nunique().eq(1).all()
assert cd.initialization_digest.nunique()==3
assert cd.initialization_digest.str.fullmatch('[0-9a-f]{64}').all()
assert np.isfinite(pd.DataFrame(cd.metrics.tolist())).all().all()
assert pd.to_datetime(cd.completed,utc=True).notna().all()
cd.drop(columns='metrics').to_csv(root/'verified_model_completion_records.csv',index=False)
report['model_completion_records']=9
report['initialization_digest_evidence']='Original uploaded completion records: all nine condition/seed keys present once, one nonempty SHA-256 digest per seed across three conditions, three different digests across seeds. Matches recorded notebook completion audit.'
report['initialization_digests_per_seed']=cd.groupby('seed').initialization_digest.first().to_dict()
report['scope']='Analysis of saved comparison records, diagnostic metadata, and model completion records; raw model weights and map-to-metric computation not independently reproduced.'
(root/'audit_results.json').write_text(json.dumps(report,indent=2))
print('Completion-record audit PASS: nine models, one matching digest per seed, three distinct seed digests.')
