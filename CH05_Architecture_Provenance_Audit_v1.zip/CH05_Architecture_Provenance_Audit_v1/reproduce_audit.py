from pathlib import Path
import json,zipfile,hashlib
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score,average_precision_score,brier_score_loss,confusion_matrix
ROOT=Path(__file__).resolve().parent;SRC=ROOT/'inputs';TABLE_DIR=ROOT/'tables';AUDIT_DIR=ROOT/'audits'
for p in (TABLE_DIR,AUDIT_DIR):p.mkdir(exist_ok=True)
for p in SRC.glob('*.zip'):
 with zipfile.ZipFile(p) as z:z.extractall(ROOT/'extracted'/p.stem)
nb=json.loads((SRC/'EDI_Architecture_Attribution_Interaction_Uncertainty_Audit_v1.ipynb').read_text())
DF=pd.read_parquet(SRC/'architecture_generalization_edi_results.parquet')
ARCHITECTURES=['efficientnetb0','resnet50','densenet121'];PREPROCESSING=['dullrazor','telea','navier_stokes'];METHODS=['gradcam','gradcampp'];BOOTSTRAP_REPS=5000;RNG_SEED=20260916
pairs=[]
for a in ARCHITECTURES:
 for c in PREPROCESSING:pairs.append(dict(comparison_type='within_architecture_preprocessing',architecture_a=a,condition_a='baseline',architecture_b=a,condition_b=c))
for c in ['baseline']+PREPROCESSING:
 for i,a in enumerate(ARCHITECTURES):
  for b in ARCHITECTURES[i+1:]:pairs.append(dict(comparison_type='cross_architecture_same_condition',architecture_a=a,condition_a=c,architecture_b=b,condition_b=c))
for p in pairs:p['pair_id']=hashlib.sha256(json.dumps(p,sort_keys=True,default=str).encode()).hexdigest()[:20]
plan=pd.DataFrame(pairs);cols=list(plan.columns)
assert DF[cols].drop_duplicates().sort_values('pair_id').reset_index(drop=True).equals(plan.sort_values('pair_id').reset_index(drop=True))
assert len(DF)==1680 and DF.image_id.nunique()==40 and DF.training_seed.eq(42).all()
assert not DF.duplicated(['pair_id','attribution_method','image_id']).any()
assert DF.groupby(['pair_id','attribution_method']).size().eq(40).all()
assert np.isfinite(DF[['pearson_corr','ssim','corr_drift','ssim_drift','edi_primary']]).all().all()
formula_error=float(abs((((1-DF.pearson_corr)/2)+(1-DF.ssim))/2-DF.edi_primary).max());assert formula_error<1e-12
DiagDF=pd.DataFrame([json.loads(p.read_text()) for p in (ROOT/'extracted/edi_architecture_generalization_attribution_diagnostics').rglob('*.json')])
keys=['architecture','condition','method','image_id']
assert len(DiagDF)==960 and not DiagDF.duplicated(keys).any()
assert not DiagDF.map_is_constant.any() and not DiagDF.map_is_zero.any() and DiagDF.map_nonfinite_count.eq(0).all()
expected={(a,c,m,i) for a in ARCHITECTURES for c in ['baseline']+PREPROCESSING for m in METHODS for i in DF.image_id.unique()}
assert set(DiagDF[keys].itertuples(index=False,name=None))==expected
lookup={tuple(r[:4]):bool(r[4]) for r in DiagDF[keys+['used_signed_fallback']].itertuples(index=False,name=None)}
for e in ('a','b'):DF['fallback_'+e]=[lookup[(getattr(r,'architecture_'+e),getattr(r,'condition_'+e),r.attribution_method,r.image_id)] for r in DF.itertuples()]
DF['fallback_either']=DF.fallback_a|DF.fallback_b
def atomic_csv(p,d):d.to_csv(p,index=False)
def atomic_json(p,o):p.write_text(json.dumps(o,indent=2))
def display(*args):pass
# Exact secondary notebook definitions and sequential RNG consumption.
code=''.join(nb['cells'][2]['source']);exec(code[code.index('def bh_adjust'):code.index("print('Source:")])
for i in (8,10,12,14):exec(''.join(nb['cells'][i]['source']))
old=ROOT/'extracted/edi_architecture_interaction_uncertainty_ham_r224_v1_outputs/tables'
exports=[]
for p in sorted(TABLE_DIR.glob('table_*.csv')):
 a=pd.read_csv(p);b=pd.read_csv(old/p.name)
 assert a.shape==b.shape and a.columns.tolist()==b.columns.tolist()
 nc=a.select_dtypes(include='number').columns;others=a.columns.difference(nc)
 assert a[others].equals(b[others])
 err=float(np.nanmax(abs(a[nc].to_numpy()-b[nc].to_numpy()))) if len(nc) else 0
 assert err<1e-12
 exports.append(dict(file=p.name,rows=len(a),maximum_numeric_error=err))
means=PrimaryDF.groupby(['architecture_a','attribution_method']).edi_primary.mean().unstack().reindex(ARCHITECTURES)
assert np.array_equal(means[METHODS].round(3).to_numpy(),[[.245,.699],[.388,.692],[.549,.647]])
means.to_csv(TABLE_DIR/'dissertation_architecture_means.csv')
ranges=CrossDF.groupby(['architecture_a','architecture_b','condition_a','attribution_method']).edi_primary.mean().groupby('attribution_method').agg(['min','max'])
assert np.array_equal(ranges.loc[METHODS].round(3).to_numpy(),[[.514,.775],[.678,.752]])
assert FallbackStatus['signed_fallback_maps']==43 and FallbackStatus['primary_comparisons_involving_fallback']==60 and FallbackStatus['maximum_absolute_rank_change']==0
models=ROOT/'extracted/edi_architecture_generalization_model_provenance/models'
completion=[];empty=[];metric_errors=[]
for p in models.rglob('DONE.json'):
 r=json.loads(p.read_text());assert r['seed']==42
 assert p.parent.name==r['condition'] and p.parent.parent.name==r['architecture']
 pred=pd.read_csv(p.parent/'test_predictions.csv');y=pred.label;prob=pred.probability
 tn,fp,fn,tp=confusion_matrix(y,(prob>=.5).astype(int),labels=[0,1]).ravel()
 metrics=dict(roc_auc=roc_auc_score(y,prob),pr_auc=average_precision_score(y,prob),brier=brier_score_loss(y,prob),sensitivity=tp/(tp+fn),specificity=tn/(tn+fp))
 err=max(abs(metrics[k]-r['metrics'][k]) for k in metrics);assert err<1e-8 # CSV probabilities have decimal precision; use a separate prediction-metric tolerance.
 metric_errors.append(err);completion.append((r['architecture'],r['condition']))
 for h in p.parent.glob('*history.csv'):
  try:n=len(pd.read_csv(h))
  except pd.errors.EmptyDataError:n=0
  if n==0:empty.append(str(h.relative_to(models)))
assert len(completion)==12 and set(completion)=={(a,c) for a in ARCHITECTURES for c in ['baseline']+PREPROCESSING}
assert len(empty)==3 and all('finetune_history' in p for p in empty)
report=dict(comparison_rows=len(DF),primary_rows=len(PrimaryDF),cross_architecture_rows=len(CrossDF),images=40,planned_pairs=21,formula_maximum_error=formula_error,diagnostic_records=960,fallback=FallbackStatus,model_completion_records=12,prediction_metric_maximum_error=max(metric_errors),empty_finetuning_histories=empty,export_reproduction=exports,bootstrap_reps=BOOTSTRAP_REPS,bootstrap_seed=RNG_SEED,dissertation_means_ranges_counts_match=True,scope='Saved comparisons, diagnostics, completion logs, prediction files and secondary analysis independently checked. Model training, map generation, raw map-to-metric computation and initial checkpoint state not reproduced.',source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in SRC.iterdir() if p.is_file()})
(ROOT/'audit_results.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));print(means)
