# Chapter 5 architecture provenance audit — 2026-10-03

PASS: all six displayed within-architecture means, cross-architecture ranges, comparison counts, fallback counts and ranking statement match Chapter 5 in HAMMOND_DISSERTATION (11).zip. No revision is needed for these results.

- 1,680 comparisons: 720 within-architecture preprocessing and 960 cross-architecture same-input-condition records. 21 pair identifiers independently reconstructed from the pilot notebook algorithm. 40 images per pair/method; no duplicate comparison keys; finite required metrics; primary EDI formula maximum error 2.22e-16.
- All 960 diagnostic records have complete expected coverage, report no constant/zero maps and no nonfinite pixels. 43 signed-fallback maps affect 60 primary comparisons. Exclusion changes means by up to 0.044042 but changes no preprocessing rank.
- Six secondary-analysis CSVs reproduce exactly numerically: 18 means, 18 architecture contrasts, 18 interaction contrasts, six rank-agreement rows, 24 cross-architecture summary rows and 18 fallback-sensitivity rows. Bootstrap: 5,000 replicates, seed 20260916, original sequential RNG consumption preserved.
- All twelve model completion records cover three architectures by four conditions. Classification metrics independently recomputed from saved test predictions agree within 1.18e-10 (small Brier discrepancies; CSV probability precision). These are saved-prediction checks, not fresh model inference.
- Three empty fine-tuning histories confirmed: DenseNet121/Telea; EfficientNetB0/baseline; EfficientNetB0/DullRazor. This is already disclosed as a logging limitation in Chapter 5. Completion records, test predictions and attribution diagnostics exist for all twelve combinations, but absent epoch logs cannot be reconstructed from them.

Displayed means:
EfficientNet-B0: Grad-CAM 0.244559, Grad-CAM++ 0.699376.
ResNet50: 0.387971, 0.691605.
DenseNet121: 0.548814, 0.646681.
Cross-architecture mean ranges round to Grad-CAM [0.514, 0.775] and Grad-CAM++ [0.678, 0.752].

Scope: analysis of saved comparisons, diagnostic metadata, completion records, saved predictions, and secondary outputs. Model training, attribution generation, initial checkpoint state and map-to-metric computation were not independently reproduced. One seed, one resolution and 40 attribution images limit interpretation. No clinical superiority, architecture-independent validity or causal architecture claim is established. Do not pool this pilot into the principal corpus.

Run reproduce_audit.py with numpy pandas scipy scikit-learn pyarrow installed. Inputs, SHA-256 hashes, reproduced CSVs and machine-readable findings are included. The script extracts local copies of input ZIPs; existing experiment sources remain untouched.
