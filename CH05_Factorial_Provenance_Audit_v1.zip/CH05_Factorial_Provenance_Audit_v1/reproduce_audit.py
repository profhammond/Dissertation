from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
OUT=Path(__file__).resolve().parent
SRC=ROOT/'factorial_audit'
FactorialDF=pd.read_parquet(SRC/'results/model_input_factorial_results.parquet')
pd.DataFrame(FactorialDF).to_csv(OUT/'source_factorial_results.csv',index=False)
TABLE_DIR=OUT
CONDITIONS=('dullrazor','telea'); METHODS=('gradcam','gradcampp')
BOOTSTRAP_REPS=5000; BOOTSTRAP_SEED=20260912
def atomic_csv(p,d): d.to_csv(p,index=False)
def display(*args): pass
nb=json.loads((SRC/'EDI_Factorial_Effect_Interaction_Reconciliation_Audit_v1.ipynb').read_text())
for i in (5,7): exec(''.join(nb['cells'][i]['source']))
recon=next((SRC/'reconciliation').iterdir())
checks={}
for name,df,keys in [('table_factorial_distance_contrasts.csv',ContrastDF,['cohort','condition','attribution_method','contrast']),('table_factorial_seed_results.csv',SeedDF,['condition','seed','comparison','attribution_method']),('table_factorial_seed_heterogeneity.csv',HeterogeneityDF,['condition','comparison','attribution_method'])]:
 old=pd.read_csv(recon/'tables'/name).sort_values(keys).reset_index(drop=True)
 new=df.sort_values(keys).reset_index(drop=True)
 assert new[keys].equals(old[keys])
 cols=new.select_dtypes(include='number').columns
 err=float(np.max(np.abs(new[cols].to_numpy()-old[cols].to_numpy())))
 checks[name]={'rows':len(new),'maximum_numeric_difference':err,'pass':err<1e-12}
assert all(x['pass'] for x in checks.values())
keys=['condition','seed','comparison','attribution_method','image_id']
groups=FactorialDF.groupby(keys[:-1]).size()
formula=(((1-FactorialDF.pearson_corr)/2)+(1-FactorialDF.ssim))/2
means=FactorialDF.groupby(['condition','attribution_method','comparison']).edi_primary.mean().unstack()
means.to_csv(OUT/'reproduced_factorial_means.csv')
align=pd.read_csv(recon/'tables/table_prior_matched_total_alignment.csv')
merged=align.merge(means.total_pipeline.rename('reproduced_total'),on=['condition','attribution_method'],validate='one_to_one')
err=float(abs(merged.reproduced_total-merged.matched_total_pipeline_mean).max())
report={'records':len(FactorialDF),'images':FactorialDF.image_id.nunique(),'cells':len(groups),'cell_sizes':sorted(groups.unique().tolist()),'duplicate_keys':int(FactorialDF.duplicated(keys).sum()),'formula_maximum_error':float(abs(formula-FactorialDF.edi_primary).max()),'bootstrap_seed':BOOTSTRAP_SEED,'bootstrap_replicates_per_contrast':BOOTSTRAP_REPS,'export_checks':checks,'prior_matched_alignment_export_maximum_error':err,'scope':'Reproduces analysis of saved comparison records. Prior matched values checked against reconciliation export, not independently recovered prior source. No training, map generation, or map-to-metric reproduction.'}
assert report['records']==2400 and report['images']==40 and report['cells']==60 and report['cell_sizes']==[40] and report['duplicate_keys']==0
assert report['formula_maximum_error']<1e-12 and err<1e-12
report['source_sha256']={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [SRC/'results/model_input_factorial_results.parquet',SRC/'EDI_Factorial_Effect_Interaction_Reconciliation_Audit_v1.ipynb',recon/'tables/table_factorial_distance_contrasts.csv']}
(OUT/'audit_results.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
print(ContrastDF.query("cohort=='complete' and attribution_method=='gradcam' and contrast=='total_minus_input_baseline_model'").to_string(index=False))
