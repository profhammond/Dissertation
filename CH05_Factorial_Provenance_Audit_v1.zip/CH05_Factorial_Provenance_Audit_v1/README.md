# Chapter 5 factorial provenance audit — 2026-10-03

PASS: all twelve displayed factorial means and the stated DullRazor Grad-CAM confidence interval agree with independent recalculation from the saved 2,400-row result file. No revision is needed for these Chapter 5 claims.

- 40 images, two preprocessing conditions, three seeds, two attribution methods, five comparisons: 60 cells with 40 records each; no duplicate comparison keys.
- Primary EDI formula maximum error: 2.22e-16.
- Reproduced all 40 bootstrap contrast rows (5,000 draws each; seed 20260912), 60 seed-summary rows, and 20 heterogeneity rows. Maximum export discrepancy: 9.72e-17.
- Grad-CAM combined minus baseline-model input-only: DullRazor 0.101150, 95% CI [0.046053, 0.157561]; Telea 0.112585, 95% CI [0.058838, 0.164418]. The dissertation only reports the Telea point estimate; its omission of an interval is not a mismatch.
- Earlier matched-total agreement is supported by the recovered reconciliation export, with maximum difference 5.55e-17. The earlier original source was not independently recovered for this check.

This audit reproduces analysis of stored comparison records. It does not reproduce model training, attribution generation, or map-to-metric computation. Distance contrasts are not additive or causal fractions. Bootstrap uncertainty is conditional on these images and fitted models.

The two figure replacements are user-reported; a new dissertation ZIP has not yet been checked to confirm the inserted PNG hashes. The retained heatmap values were independently verified in the preceding audit.

Run: install numpy pandas pyarrow, then `python reproduce_audit.py`. Original notebook code for contrast and seed summaries is included in the input notebook and executed by the audit script. Source SHA-256 hashes are in audit_results.json. Existing source artifacts remain untouched.
