# Chapter 5 formulation provenance audit

The current Chapter 5 alternative-formulation summary and rank claims reproduce from the full 51,840-row, nine-configuration dissertation manifest. No dissertation table or prose revision is required for this item.

All six formulations preserve the aggregate preprocessing order: Telea, Navier–Stokes, DullRazor, HDBMIE, diffusion, fixed untrained CNN. The global and geometric formulations exchange only HAM10000 and COVIDx at configuration ranks 5 and 6 (Spearman 0.983333; Kendall 0.944444). Other alternatives preserve the configuration order.

The original manifest contains inherited inconsistent alternative-formulation columns. This audit does not establish when or why they became inconsistent and does not attribute them to manuscript-specific code. Existing Chapter 5 exports reproduce when recalculated from the drift components.

A separate derived manifest replaces only edi_structural, edi_global, edi_geometric, edi_max and edi_rms using:
- structural = ssim_drift
- global = corr_drift
- geometric = sqrt(corr_drift * ssim_drift)
- maximum = max(corr_drift, ssim_drift)
- RMS = sqrt((corr_drift**2 + ssim_drift**2)/2)

Primary EDI, component columns, identifiers, and all other columns are preserved. This derived file is an aggregation source for future formulation analyses; it is not a replacement for original model/map provenance. Original canonical files and live Google Drive files were not modified. Keep source and derived hashes with any future exports. No retraining or attribution generation is needed.

Store this package with the dissertation provenance records. Before using the derived CSV in Colab, check its row counts, source scope, and SHA-256 against audit_status.json. The full provenance audit remains open for other analytical figures and original attribution/model lineage.
