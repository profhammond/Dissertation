from pathlib import Path
import json
import numpy as np,pandas as pd
from scipy.stats import spearmanr
OUT=Path('dissertation-repo/prospective_six_method/classification_relationship_v1')
tables={}
for name,path in [('HAM','six-full-output/paired_comparisons.csv'),('ISIC','localization-full-output/pair_metrics.csv')]:
 d=pd.read_csv(path)
 if name=='HAM':d=d.rename(columns={'baseline_correct':'correct_baseline','comparison_correct':'correct_comparison'})
 else:d=d[(d.pair_type=='preprocessing_pair_plan.csv')&(d.version=='official')].rename(columns={'probability_baseline':'baseline_probability','probability_comparison':'comparison_probability'})
 assert (d.correct_baseline==((d.baseline_probability>=.5).astype(int)==d.label)).all()
 assert (d.correct_comparison==((d.comparison_probability>=.5).astype(int)==d.label)).all()
 tables[name]=d
results=pd.read_csv(OUT/'signed_prediction_error_associations.csv');errors=[]
for r in results.itertuples():
 d=tables[r.cohort];g=d[(d.label==r.label)&(d.method==r.method)&(d.condition==r.condition)].copy()
 units=['image_id','seed','condition']
 if r.support!='available':
  eligible=d.groupby(units).metric_defined.all();g=g[pd.MultiIndex.from_frame(g[units]).map(eligible)]
 if r.support=='common_fallback_free':
  bad=(d.baseline_signed_fallback|d.comparison_signed_fallback).groupby([d.image_id,d.seed,d.condition]).any()
  g=g[~pd.MultiIndex.from_frame(g[units]).map(bad)]
 g=g[g.metric_defined];assert len(g)==r.n_records and g.image_id.nunique()==r.n_images
 y=(g.comparison_probability-g.label)**2-(g.baseline_probability-g.label)**2 if r.outcome=='brier_delta' else np.where(g.label==1,g.comparison_probability-g.baseline_probability,g.baseline_probability-g.comparison_probability)
 z=spearmanr(g.edi,y).statistic;errors.append(abs(z-r.rho));assert abs(z-r.rho)<1e-12
# Independent individual-SciPy replay of one 5000-draw correlation interval.
d=tables['ISIC'];ids=sorted(d.loc[d.label==0,'image_id'].unique());g=d[(d.label==0)&(d.method=='gradcam')&(d.condition=='dullrazor')].set_index(['image_id','seed']).reindex(pd.MultiIndex.from_product([ids,[42,1337,2026]]))
x=g.edi.to_numpy().reshape(50,3);y=((g.comparison_probability-g.label)**2-(g.baseline_probability-g.label)**2).to_numpy().reshape(50,3)
rng=np.random.default_rng(20261004);draw=rng.integers(50,size=(5000,50));boot=np.array([spearmanr(x[a].ravel(),y[a].ravel()).statistic for a in draw])
r=results[(results.cohort=='ISIC')&(results.label==0)&(results.method=='gradcam')&(results.condition=='dullrazor')&(results.support=='available')&(results.outcome=='brier_delta')].iloc[0]
np.testing.assert_allclose(np.percentile(boot,[2.5,97.5]),[r.ci_low,r.ci_high],atol=1e-12,rtol=0)
status=dict(passed=True,prediction_correctness_recomputed=True,source_correlation_estimates_verified=len(errors),maximum_point_estimate_error=float(max(errors)),independent_scipy_bootstrap_draws=5000,bootstrap_contrast='ISIC non-melanoma GradCAM Dullrazor signed Brier change')
(OUT/'independent_verification.json').write_text(json.dumps(status,indent=2));print(json.dumps(status,indent=2))
