# EDI and classification behavior — October 4, 2026

## Answer to the research question

There are measurable relationships between drift and classification behavior, but they are method-, class- and cohort-dependent. The verified records do not support a general statement that higher drift means poorer classification or that lower drift means reliable classification.

For HAM melanoma cases, incorrect post-preprocessing predictions have higher average EDI than correct predictions for several methods. This is an exploratory, sparsely supported association: correct outcomes occur in only four distinct melanoma images, and most incorrect outcomes were already incorrect before preprocessing. The corresponding ISIC melanoma comparisons do not resolve a consistent correctness relationship. In ISIC non-melanoma GradCAM comparisons, higher EDI is associated with improved signed probability error. Together these findings require distinguishing the magnitude of prediction change from its direction and correctness.

## Data and outcomes

The analysis uses the verified prospective six-method HAM cohort (40 images, 20 per class, three fixed models) and official-reference ISIC CAM cohort (100 images, 50 per class, three fixed models). HAM supplies six implementations and ISIC two. Both evaluate original-to-Dullrazor and original-to-Telea input changes using fixed models and a fixed melanoma explanation target. GradCAM++ remains the documented first-gradient-power approximation; EigenCAM is class-independent.

Classification outcomes are deduplicated by image, seed and condition. Attribution methods do not create additional classification events. The unchanged probability threshold is 0.5. This is a relationship analysis of existing records, not a new training or attribution experiment, and does not evaluate the separate class-weighting models.

Three outcomes are examined separately within each true label class:

1. Correctness after preprocessing: mean EDI for incorrect predictions minus mean EDI for correct predictions.
2. Correctness transitions: deteriorated versus stable correct among initially correct cases; improved versus stable incorrect among initially incorrect cases.
3. Signed probability changes: squared probability-error change (Brier contribution) and probability change assigned to the true class. Positive Brier change is deterioration; positive true-class-probability change is improvement.

## Classification transition support

| Cohort/class | Condition | Stable correct | Stable incorrect | Correct→incorrect | Incorrect→correct |
|---|---|---:|---:|---:|---:|
| HAM melanoma | Dullrazor | 9 | 48 | 3 | 0 |
| HAM melanoma | Telea | 8 | 48 | 4 | 0 |
| HAM non-melanoma | Dullrazor | 59 | 1 | 0 | 0 |
| HAM non-melanoma | Telea | 59 | 1 | 0 | 0 |
| ISIC melanoma | Dullrazor | 25 | 116 | 0 | 9 |
| ISIC melanoma | Telea | 25 | 117 | 0 | 8 |
| ISIC non-melanoma | Dullrazor | 149 | 1 | 0 | 0 |
| ISIC non-melanoma | Telea | 149 | 1 | 0 | 0 |

Numbers count model/image observations across three evaluated seeds, not independent patients or images. HAM deteriorations involve three images per condition; ISIC improvements involve four images per condition. HAM melanoma stable-correct records involve four images; ISIC melanoma correct-after records involve fourteen images. Each cohort's non-melanoma incorrect observations involve a single image. No new non-melanoma errors occur under these preprocessing comparisons.

## Drift and post-preprocessing correctness

For HAM melanoma, available-support mean-EDI differences (incorrect minus correct) are:

| Method | Dullrazor difference [95% interval] | Telea difference [95% interval] |
|---|---|---|
| GradCAM | 0.129 [0.071, 0.193] | 0.118 [0.059, 0.180] |
| GradCAM++ approximation | 0.070 [0.013, 0.134] | 0.068 [0.009, 0.134] |
| EigenCAM | 0.111 [0.002, 0.232] | 0.108 [0.002, 0.230] |
| ScoreCAM | 0.045 [−0.073, 0.133] | 0.054 [−0.081, 0.133] |
| Integrated Gradients | 0.027 [−0.045, 0.097] | 0.027 [−0.046, 0.098] |
| SHAP Partition | 0.121 [0.069, 0.173] | 0.119 [0.062, 0.170] |

All these HAM melanoma comparisons have a sparse correct group (four distinct images). Fifty-eight of the 5,000 bootstrap draws lack a correct group; intervals use the 4,942 defined draws and are conditional on both groups appearing. They are not robust classification-failure thresholds. On this class, common and common-fallback-free support retain the same observations.

For ISIC melanoma, GradCAM mean differences are 0.037 [−0.028, 0.101] and 0.037 [−0.031, 0.102]; GradCAM++ approximation differences are −0.031 [−0.087, 0.025] and −0.027 [−0.087, 0.031]. All four available-support intervals include zero. This does not establish absence of association; it limits a consistent high-drift/error claim across the two cohorts.

These comparisons measure correctness status after preprocessing. They do not show that preprocessing newly created most errors: HAM has 48 persistently incorrect melanoma records per condition, compared with only 3–4 deteriorations. Baseline difficulty, confidence and training variability have not been adjusted for in these contrasts.

## Transition comparisons

HAM GradCAM deterioration-versus-stable-correct mean differences are positive (0.030 in each condition), but supported by just three deteriorating images and four stable-correct images. Exactly **255 of 5,000 draws** lack at least one group. These are descriptive pilot contrasts with conditional intervals, not strong evidence of a general failure relationship. Full numerical results and support counts are supplied for every method, including non-estimable comparisons.

ISIC has no deterioration events at threshold 0.5. Improved melanoma cases have positive mean-EDI differences relative to stable incorrect cases, but available-support intervals include zero for both CAM implementations and conditions. Those improvements involve only four images, and 70 bootstrap draws have no improved group. High drift therefore also occurs in cases that improve; the sparse evidence cannot support a reliable direction rule.

## Signed probability-error changes

Every HAM available-support association between EDI and signed Brier change has an interval containing zero after separating the two true classes. Thus the previously established associations with absolute probability movement do not translate into a clear direction of probability-error change in this cohort.

For ISIC non-melanoma GradCAM, signed Brier-change associations are negative:

- Dullrazor: rho −0.262, interval [−0.442, −0.042].
- Telea: rho −0.290, interval [−0.468, −0.078].

Higher EDI tends to accompany more favorable probability-error changes in these comparisons. Fallback-free common support retains negative estimates: −0.235 [−0.441, −0.003] and −0.250 [−0.452, −0.024]. These exploratory intervals are not adjusted for the many examined contrasts. ISIC GradCAM++ approximation/non-melanoma and both CAM implementations/melanoma have available-support signed Brier intervals containing zero.

All true-class probability associations are supplied alongside these squared-error results. Descriptive within-class EDI terciles are also supplied; their cuts are data-derived, not validated thresholds or evidence of incremental prediction performance.

## Statistical specification and limitations

The analysis was specified after outcomes were available and is exploratory. For each true class, 5,000 image-cluster bootstrap draws (seed 20261004) resample that class's original image universe and carry all three fixed model records together. Shared image draws are used across methods, conditions and support analyses within each class. Comparisons use available support, common support across all methods in that cohort, and common support without any endpoint signed fallback. Missing or constant outcomes remain missing rather than receiving zero EDI.

Percentile 95% intervals use defined draws only. Missing-group draws and non-estimable original contrasts are explicitly recorded. Fewer than ten supporting images in either contrast group is flagged as sparse, not silently excluded. No multiplicity adjustment, population-seed inference, causal inference, incremental-value model, outcome-based model selection or threshold tuning is performed. Class-specific correctness contrasts are important because nearly all non-melanoma predictions are correct while many melanoma predictions are incorrect. Pooling classes could obscure that asymmetry.

The analysis does not explain why the evaluated models fail on particular images. Training imbalance, image difficulty, domain transfer, baseline confidence, image lineage and implementation differences can affect interpretation. The known dataset independence and classifier-performance limitations remain unchanged.

## Defensible dissertation conclusion

“Attribution drift exhibited conditional relationships with classification behavior. In the prospective HAM melanoma cohort, some methods showed higher mean drift for incorrect than correct predictions, although the correctly classified image support was small. The verified ISIC analyses did not show a consistent melanoma correctness relationship, and higher GradCAM drift in non-melanoma cases was associated with improved probability error. These results support evaluating EDI alongside class-specific prediction outcomes rather than interpreting higher drift as a general indicator of classification deterioration.”

## Verification and files

Source hashes and settings are in `analysis_manifest.json`. The verification script recomputes correctness from the fixed probability threshold, checks all 192 correlation point estimates directly against SciPy, and independently replays one 5,000-draw correlation interval. Detailed contrasts preserve observed group counts, image support and undefined bootstrap counts. Unique prediction tables prevent attribution methods from multiplying event denominators. No dissertation edits or source experiment modifications were performed.
