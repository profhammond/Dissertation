"""Exploratory association of verified EDI with classification behavior, not causation."""
from pathlib import Path
import json,hashlib,warnings
import numpy as np,pandas as pd
from scipy.stats import rankdata,spearmanr
OUT=Path('dissertation-repo/prospective_six_method/classification_relationship_v1');OUT.mkdir(parents=True,exist_ok=True)
SEED=20261004;B=5000
def mean(a,axis):
 n=np.isfinite(a).sum(axis=axis);s=np.nansum(a,axis=axis)
 return np.divide(s,n,out=np.full(np.shape(s),np.nan),where=n>0)
def ranks_rho(a,b):
 ok=np.isfinite(a)&np.isfinite(b);a=rankdata(np.where(ok,a,np.nan),axis=1,nan_policy='omit');b=rankdata(np.where(ok,b,np.nan),axis=1,nan_policy='omit')
 a-=mean(a,1)[:,None];b-=mean(b,1)[:,None];den=np.sqrt(np.nansum(a*a,1)*np.nansum(b*b,1))
 return np.divide(np.nansum(a*b,1),den,out=np.full(len(a),np.nan),where=den>0)
def interval(a):
 defined=a[np.isfinite(a)];return (*np.percentile(defined,[2.5,97.5]),len(defined),B-len(defined)) if len(defined) else (np.nan,np.nan,0,B)
paths={'HAM':'six-full-output/paired_comparisons.csv','ISIC':'localization-full-output/pair_metrics.csv'}
counts=[];groupstats=[];contrasts=[];correlations=[];bins=[];events=[];independent_errors=[]
for cohort,path in paths.items():
 d=pd.read_csv(path)
 if cohort=='HAM':d=d.rename(columns={'baseline_correct':'correct_baseline','comparison_correct':'correct_comparison'})
 else:
  d=d[(d.pair_type=='preprocessing_pair_plan.csv')&(d.version=='official')].copy()
  d=d.rename(columns={'probability_baseline':'baseline_probability','probability_comparison':'comparison_probability','baseline_signed_fallback':'baseline_signed_fallback','comparison_signed_fallback':'comparison_signed_fallback'})
 units=['image_id','seed','condition'];methods=sorted(d.method.unique());ids=sorted(d.image_id.unique());lab=d.groupby('image_id').label.first().reindex(ids)
 assert not d.duplicated(units+['method']).any()
 # Predictions/correctness belong to model/input, not attribution method.
 for c in ['baseline_probability','comparison_probability','label','correct_baseline','correct_comparison']:
  assert d.groupby(units)[c].nunique().eq(1).all()
 d['transition']=np.select([d.correct_baseline & d.correct_comparison,d.correct_baseline & ~d.correct_comparison,~d.correct_baseline & d.correct_comparison],['stable_correct','deteriorated','improved'],default='stable_incorrect')
 d['brier_delta']=(d.comparison_probability-d.label)**2-(d.baseline_probability-d.label)**2
 d['true_class_probability_delta']=np.where(d.label==1,d.comparison_probability-d.baseline_probability,d.baseline_probability-d.comparison_probability)
 eligible=d.groupby(units).metric_defined.all();fb=(d.baseline_signed_fallback|d.comparison_signed_fallback).groupby([d.image_id,d.seed,d.condition]).any()
 d['common']=pd.MultiIndex.from_frame(d[units]).map(eligible).to_numpy();d['common_free']=d.common & ~pd.MultiIndex.from_frame(d[units]).map(fb).to_numpy()
 unique=d.drop_duplicates(units)
 for (condition,label),g in unique.groupby(['condition','label']):
  for transition in ['stable_correct','stable_incorrect','deteriorated','improved']:
   sg=g[g.transition==transition];counts.append(dict(cohort=cohort,condition=condition,label=label,transition=transition,records=len(sg),distinct_images=sg.image_id.nunique(),planned_records=len(g)))
 unique.to_csv(OUT/f'{cohort.lower()}_unique_prediction_outcomes.csv',index=False)
 for label in [0,1]:
  cluster_ids=list(lab.index[lab==label]);n=len(cluster_ids);rng=np.random.default_rng(SEED);draw=rng.integers(n,size=(B,n))
  ix=pd.MultiIndex.from_product([cluster_ids,[42,1337,2026]],names=['image_id','seed'])
  for (method,condition),g in d[d.label==label].groupby(['method','condition']):
   g=g.set_index(['image_id','seed']).reindex(ix);assert len(g)==n*3 and not g.transition.isna().any()
   for support in ['available','common','common_fallback_free']:
    keep=g.metric_defined.to_numpy(copy=True)
    if support=='common':keep &= g.common.to_numpy()
    if support=='common_fallback_free':keep &= g.common_free.to_numpy()
    edi=np.where(keep,g.edi.to_numpy(),np.nan).reshape(n,3);transition=g.transition.to_numpy().reshape(n,3)
    prefix=dict(cohort=cohort,label=label,method=method,condition=condition,support=support)
    for t in ['stable_correct','stable_incorrect','deteriorated','improved']:
     val=np.where(transition==t,edi,np.nan);finite=np.isfinite(val);a=val[finite]
     groupstats.append(dict(**prefix,transition=t,n_records=len(a),n_images=int(finite.any(axis=1).sum()),mean_edi=float(np.mean(a)) if len(a) else np.nan,median_edi=float(np.median(a)) if len(a) else np.nan))
    # Error association, and event contrasts conditional on the original correctness.
    masks={'incorrect_after':~g.correct_comparison.to_numpy().reshape(n,3),'correct_after':g.correct_comparison.to_numpy().reshape(n,3),
      'deteriorated':transition=='deteriorated','stable_correct':transition=='stable_correct','improved':transition=='improved','stable_incorrect':transition=='stable_incorrect'}
    for akey,bkey in [('incorrect_after','correct_after'),('deteriorated','stable_correct'),('improved','stable_incorrect')]:
     a=np.where(masks[akey],edi,np.nan);b=np.where(masks[bkey],edi,np.nan)
     boots=mean(a[draw],(1,2))-mean(b[draw],(1,2));lo,hi,defined,undefined=interval(boots)
     point=float(mean(a,(0,1))-mean(b,(0,1)))
     na=int(np.isfinite(a).sum());nb=int(np.isfinite(b).sum());ca=int(np.isfinite(a).any(axis=1).sum());cb=int(np.isfinite(b).any(axis=1).sum())
     contrasts.append(dict(**prefix,contrast=f'{akey}_minus_{bkey}',difference_mean_edi=point,ci_low=lo,ci_high=hi,n_records_a=na,n_records_b=nb,n_images_a=ca,n_images_b=cb,
       bootstrap_defined=defined,bootstrap_undefined=undefined,sparse_group=ca<10 or cb<10,estimable=na>0 and nb>0))
    for outcome in ['brier_delta','true_class_probability_delta']:
     y=np.where(keep,g[outcome].to_numpy(),np.nan).reshape(n,3);point=float(ranks_rho(edi.reshape(1,-1),y.reshape(1,-1))[0])
     boots=ranks_rho(edi[draw].reshape(B,-1),y[draw].reshape(B,-1));lo,hi,defined,undefined=interval(boots)
     finite=np.isfinite(edi)&np.isfinite(y)
     ref=spearmanr(edi[finite],y[finite]).statistic if finite.sum()>1 else np.nan
     if np.isfinite(ref):independent_errors.append(abs(ref-point));assert abs(ref-point)<1e-12
     correlations.append(dict(**prefix,outcome=outcome,rho=point,ci_low=lo,ci_high=hi,n_records=int(finite.sum()),n_images=int(finite.any(axis=1).sum()),bootstrap_defined=defined,bootstrap_undefined=undefined))
    # Descriptive within-class drift terciles; data-derived cuts, no clinical thresholds.
    flat=edi.ravel();finite=np.isfinite(flat)
    if finite.any():
     q1,q2=np.nanquantile(flat,[1/3,2/3]);category=np.where(flat<=q1,'lower',np.where(flat<=q2,'middle','higher'))
     for name in ['lower','middle','higher']:
      take=finite & (category==name);sg=g.iloc[np.flatnonzero(take)]
      bins.append(dict(**prefix,drift_tercile=name,cut_low=q1,cut_high=q2,n_records=len(sg),n_images=sg.reset_index().image_id.nunique(),
       mean_edi=sg.edi.mean(),error_rate_after=float((~sg.correct_comparison).mean()) if len(sg) else np.nan,
       deterioration_records=int(sg.transition.eq('deteriorated').sum()),improvement_records=int(sg.transition.eq('improved').sum())))
 for t in ['deteriorated','improved']:
  ev=d[d.transition==t].copy();ev['cohort']=cohort;events.append(ev)
pd.DataFrame(counts).to_csv(OUT/'classification_transition_counts.csv',index=False)
pd.DataFrame(groupstats).to_csv(OUT/'edi_by_classification_outcome.csv',index=False)
pd.DataFrame(contrasts).to_csv(OUT/'classification_outcome_drift_contrasts.csv',index=False)
pd.DataFrame(correlations).to_csv(OUT/'signed_prediction_error_associations.csv',index=False)
pd.DataFrame(bins).to_csv(OUT/'descriptive_drift_terciles.csv',index=False)
pd.concat(events,ignore_index=True).to_csv(OUT/'classification_transition_method_records.csv',index=False)
manifest=dict(analysis_type='exploratory post-outcome relationship analysis, not preregistered',seed=SEED,bootstrap_draws=B,
 resampling='image clusters within each label class; all three fixed seeds carried together; same image draws across methods, conditions and supports',
 brier_delta='(comparison probability minus label)^2 minus (baseline probability minus label)^2; positive is deterioration in probability error',
 true_class_probability_delta='positive is improvement in probability assigned to the true class',
 error_difference='mean EDI for incorrect comparison predictions minus mean EDI for correct comparison predictions',
 sparse_definition='fewer than 10 distinct supporting images in either contrast group; caution flag, not an exclusion rule',
 undefined_draws='retained and counted; percentile intervals use defined draws only and are conditional on both groups appearing',
 threshold=.5,class_stratification=True,multiplicity_adjusted=False,incremental_value_tested=False,causation_tested=False,
 rho_estimates_independently_verified=len(independent_errors),rho_max_error=float(max(independent_errors)),
 source_hashes={c:hashlib.sha256(Path(p).read_bytes()).hexdigest() for c,p in paths.items()},script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT/'analysis_manifest.json').write_text(json.dumps(manifest,indent=2));print(pd.DataFrame(counts).to_string(index=False));print('Available-support signed Brier associations');print(pd.DataFrame(correlations).query('support == "available" and outcome == "brier_delta"').to_string(index=False))
