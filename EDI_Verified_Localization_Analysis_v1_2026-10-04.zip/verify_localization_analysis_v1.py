"""Independent rank/bootstrap spot verification and classification reconciliation."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score,average_precision_score,brier_score_loss

p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--analysis',type=Path,required=True);a=p.parse_args()
source=pd.read_csv(a.input/'pair_metrics.csv'); results=pd.read_csv(a.analysis/'localization_associations.csv')
g=source[(source.version=='official')&(source.method=='gradcam')&(source.condition=='dullrazor')].sort_values(['image_id','seed'])
assert len(g)==300
labels=g.groupby('image_id',sort=True).label.first().to_numpy();rng=np.random.default_rng(20261004)
indices=np.concatenate([rng.choice(np.flatnonzero(labels==lab),(5000,sum(labels==lab)),replace=True) for lab in (0,1)],axis=1)
x=g.edi.to_numpy().reshape(100,3);y=g.nearest_absolute_lesion_mass_delta.to_numpy().reshape(100,3)
bootstrap=np.array([spearmanr(x[index].ravel(),y[index].ravel()).statistic for index in indices])
r=results[(results.scope=='official_primary')&(results.method=='gradcam')&(results.condition=='dullrazor')&(results.mask_raster=='nearest')&(results.support=='available')&(results.outcome=='absolute_lesion_mass_delta')].iloc[0]
np.testing.assert_allclose([r.rho,r.ci_low,r.ci_high],[spearmanr(x.ravel(),y.ravel()).statistic,*np.percentile(bootstrap,[2.5,97.5])],atol=1e-12,rtol=0)
pred=pd.read_csv(a.input/'predictions.csv');aliases=pd.read_csv(a.input/'image_version_aliases.csv');same=set(aliases.loc[aliases.current_bytes_identical,'image_id'])
current=pd.concat([pred[pred.version=='current'],pred[(pred.version=='official')&pred.image_id.isin(same)]])
performance=pd.read_csv(a.analysis/'classification_context.csv');errors=[]
for r in performance.itertuples():
 data=pred[pred.version=='official'] if r.scope=='official' else current
 data=data[(data.seed==r.seed)&(data.condition==r.condition)]
 values=[roc_auc_score(data.label,data.probability),average_precision_score(data.label,data.probability),brier_score_loss(data.label,data.probability)]
 errors.extend(np.abs(np.array(values)-[r.roc_auc,r.average_precision,r.brier_score]))
assert max(errors)<1e-12
assert (results.bootstrap_defined+results.bootstrap_undefined==5000).all()
assert len(results)==240 and results.bootstrap_undefined.sum()==0
status=dict(passed=True,independent_scipy_bootstrap_draws=5000,primary_contrast='GradCAM Dullrazor absolute lesion-mass change',
  classification_rows_recomputed_with_sklearn=len(performance),classification_max_error=float(max(errors)),association_rows=len(results),undefined_bootstraps=int(results.bootstrap_undefined.sum()))
(a.analysis/'independent_analysis_checks.json').write_text(json.dumps(status,indent=2));print(json.dumps(status,indent=2))
