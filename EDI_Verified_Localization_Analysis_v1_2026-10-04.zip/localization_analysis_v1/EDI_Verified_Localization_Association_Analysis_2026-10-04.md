# Verified localization association analysis — October 4, 2026

## Scope and interpretation

This prospective analysis uses the audited full-generation bundle and the internally dated frozen design v1.1. It is a separate dataset from the historical localization experiments and the independent running six-method HAM cohort. EDI quantifies map disagreement; lesion attribution mass measures spatial correspondence with annotations. Association does not establish causal deterioration, faithfulness, diagnostic usefulness or added value beyond prediction information.

## Findings and defensible conclusion

In this cohort, EDI was positively associated with the magnitude of lesion-mass change for both methods and both preprocessing conditions (rho 0.465–0.513). All four primary absolute-change intervals were above zero. Excluding fallback pairs retained this pattern (GradCAM rho 0.438 and 0.458; GradCAM++ unchanged). Each fixed seed also had a positive absolute-change point estimate. This supports a measured relationship between map disagreement and spatial redistribution under these evaluated conditions.

Signed changes differ by method. GradCAM's primary associations were positive, meaning higher EDI tended to accompany increased lesion mass, rather than deterioration. After fallback exclusion, the Telea signed-change interval included zero. GradCAM++ signed-change intervals included zero in both conditions. Thus the results do not justify interpreting high EDI as worse localization or ranking explanation quality by drift.

The magnitudes deserve context: median absolute lesion-mass changes were 0.0081 and 0.0104 for GradCAM and 0.0037 and 0.0043 for GradCAM++ (about 0.37–1.04 percentage points). A rank association does not establish a practically large change. Both quantities are calculated from the same attribution maps, so some association is structurally expected; this is not independent validation of diagnostic value.

The full current-copy sensitivity retained positive absolute-change associations (rho 0.445–0.531), and both provenance-defined subsets retained positive point estimates. Alternate raster results are fully tabulated. These analyses share images and maps with the primary arm and do not count as new replications.

Secondary EDI–absolute-probability-change associations were positive (rho 0.513–0.530), with all four image-cluster intervals above zero. This contrasts with the earlier HAM factorial cohort's inconclusive associations and should be reported as cohort-dependent evidence, without replacing those results. Class switches were sparse (9 Dullrazor and 8 Telea observations among 300 model/image pairs each); these counts are shared between methods, not additional events. There is no image-grouped incremental-value model in this analysis.

Official-original ROC-AUC ranged 0.6932–0.7312, but melanoma sensitivity at 0.5 remained 0.12–0.20. The classifier context limits a clinical interpretation of localization findings.

Suggested dissertation claim: “In the verified prospective ISIC cohort, preprocessing-associated EDI was positively associated with the magnitude of lesion attribution-mass changes for both evaluated CAM implementations. Directional associations depended on method and fallback handling, supporting EDI as a measure of attribution change while limiting its interpretation as an explanation-quality indicator. Added predictive value remains untested.”

## Primary official-reference results

Each method/condition has 300 paired observations from 100 images (50 per class) and three fixed models. Signed change is preprocessing minus original lesion mass; positive values indicate increased mass inside the lesion. Absolute change measures magnitude in either direction. The mask uses native binary >0 followed by nearest-neighbor resizing to 224.

| Method | Condition | Outcome | Spearman rho | 95% image-cluster interval |
|---|---|---|---:|---|
| gradcam | dullrazor | lesion_mass_delta | 0.293 | [0.118, 0.454] |
| gradcam | dullrazor | absolute_lesion_mass_delta | 0.495 | [0.371, 0.606] |
| gradcam | telea | lesion_mass_delta | 0.272 | [0.099, 0.433] |
| gradcam | telea | absolute_lesion_mass_delta | 0.513 | [0.390, 0.622] |
| gradcam_pp | dullrazor | lesion_mass_delta | -0.047 | [-0.231, 0.149] |
| gradcam_pp | dullrazor | absolute_lesion_mass_delta | 0.465 | [0.310, 0.599] |
| gradcam_pp | telea | lesion_mass_delta | -0.101 | [-0.289, 0.104] |
| gradcam_pp | telea | absolute_lesion_mass_delta | 0.503 | [0.352, 0.631] |

## Signed-fallback sensitivity

Exclude a pair when either endpoint uses signed fallback. This changes support and the estimand. Signed maps normalized to nonnegative values do not retain the interpretation of exclusively positive melanoma evidence. All maps remain in the audit and primary available-support analysis.

| Method | Condition | Outcome | Pairs | rho | 95% interval |
|---|---|---|---:|---:|---|
| gradcam | dullrazor | lesion_mass_delta | 276 | 0.197 | [0.018, 0.377] |
| gradcam | dullrazor | absolute_lesion_mass_delta | 276 | 0.438 | [0.290, 0.568] |
| gradcam | telea | lesion_mass_delta | 275 | 0.165 | [-0.013, 0.344] |
| gradcam | telea | absolute_lesion_mass_delta | 275 | 0.458 | [0.311, 0.585] |
| gradcam_pp | dullrazor | lesion_mass_delta | 300 | -0.047 | [-0.231, 0.149] |
| gradcam_pp | dullrazor | absolute_lesion_mass_delta | 300 | 0.465 | [0.310, 0.599] |
| gradcam_pp | telea | lesion_mass_delta | 300 | -0.101 | [-0.289, 0.104] |
| gradcam_pp | telea | absolute_lesion_mass_delta | 300 | 0.503 | [0.352, 0.631] |

## Uncertainty and support

5,000 bootstrap draws, seed 20261004, resample image IDs within true-label classes and carry all three fixed-model records together. Ranks and ties are recomputed in every draw. Intervals are 95% percentile intervals; this measures image sampling variability for these models, not variability across a population of training seeds. The same sampled image indices are shared across methods, conditions, raster and support analyses within each scope. For fallback-free analyses, resample the original image universe and then omit flagged pairs; draw-specific support can vary. Undefined bootstrap correlations are retained in the results table rather than replaced with zero. These exploratory intervals are not multiplicity-adjusted tests or a basis for method rankings.

All planned maps were nonconstant and all planned pair metrics and localization outcomes were defined. Consequently available support and common two-method support coincide exactly; a duplicated common-support result table is unnecessary. Fallback-free support is method-specific and should not be described as common support.

## Sensitivity and classification context

`localization_associations.csv` includes the full current-copy cohort (26 official computations reused by byte identity plus 74 differing copies), the 26 identical-image subset (16 melanoma, 10 non-melanoma), the 74 differing images in each version, and all three mask rasters. These are correlated sensitivities, not independent replications. Historical-copy full-frame coordinate correspondence remains an assumption; raster-path sensitivity cannot rule out unknown crops or rotations.

`localization_descriptive_by_seed.csv` reports each fixed model and pooled descriptive results. `classification_context.csv` retains all models and conditions, ROC-AUC, average precision, Brier score and unchanged 0.5 sensitivity/specificity. `secondary_prediction_associations.csv` reports exploratory EDI–absolute-probability-change associations using the same image-cluster procedure. `image_version_descriptive.csv` reports reference-to-current map comparisons separately from preprocessing comparisons. Localization is not a perturbation-faithfulness endpoint.

## Reproduction and audit limits

Run `analyze_verified_localization_v1.py --input <extracted full bundle> --output <new analysis directory>`. Source records are not modified. Source hashes, software versions and settings are in `analysis_manifest.json`. Generation review independently reproduced the prespecified 108-map compact sample and checked all exported pair-table formulas and identities. The compact sample consists of reused smoke cases; raw-array reproduction of every newly generated full-run map was not possible from this bundle. Full source arrays remain on Drive. Existing label and training-overlap limitations remain in the frozen design.
