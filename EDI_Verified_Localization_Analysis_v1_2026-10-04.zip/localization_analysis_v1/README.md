# Localization analysis v1

Read `EDI_Verified_Localization_Association_Analysis_2026-10-04.md` first. CSVs preserve numerical precision; estimates are exploratory and confidence intervals are not multiplicity-adjusted.

The independent verification script reproduced all 5,000 bootstrap draws for the official GradCAM/Dullrazor absolute lesion-mass contrast using individual SciPy Spearman calls, then reconciled all 18 classification rows against scikit-learn. Maximum classification discrepancy was 2.22e-16. All 240 association rows had 5,000 defined bootstrap correlations. See `independent_analysis_checks.json`.

For the eight primary official-arm correlations, alternate mask-raster estimates differed from the nearest-mask estimate by at most 0.004784. This numerical sensitivity does not prove the historical current-copy coordinate assumption.

The GradCAM++ name refers to the locked first-gradient-power approximation specified in the frozen design, rather than an independently verified exact higher-derivative implementation.

The companion Python scripts are located one directory above this folder. To reproduce, provide the extracted audited generation bundle as `--input` and a fresh directory as `--output` to the analysis script, then supply that directory as `--analysis` to the verification script. Requires numpy, pandas, scipy and, for verification only, scikit-learn.

No dissertation source edit or GitHub upload has been performed. The six-method HAM run remains separate and its final bundle has not yet been reviewed.
