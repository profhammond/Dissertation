"""Frozen-plan localization analysis. Run with --input and --output directories.

Requires numpy, pandas, scipy. Never modifies generation records.
"""
import argparse, hashlib, json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import rankdata, spearmanr

BOOT = 5000
SEED = 20261004

def rho_batch(x, y):
    ok = np.isfinite(x) & np.isfinite(y)
    a = rankdata(np.where(ok, x, np.nan), axis=1, nan_policy='omit')
    b = rankdata(np.where(ok, y, np.nan), axis=1, nan_policy='omit')
    n = ok.sum(axis=1)
    a -= np.divide(np.nansum(a, axis=1), n, where=n>0)[:,None]
    b -= np.divide(np.nansum(b, axis=1), n, where=n>0)[:,None]
    den = np.sqrt(np.nansum(a*a, axis=1)*np.nansum(b*b, axis=1))
    return np.divide(np.nansum(a*b, axis=1), den, out=np.full(len(n),np.nan), where=den>0)

def main():
    p=argparse.ArgumentParser(); p.add_argument('--input',type=Path,required=True); p.add_argument('--output',type=Path,required=True)
    args=p.parse_args(); src=args.input; out=args.output; out.mkdir(parents=True,exist_ok=True)
    pairs=pd.read_csv(src/'pair_metrics.csv'); aliases=pd.read_csv(src/'image_version_aliases.csv')
    predictions=pd.read_csv(src/'predictions.csv'); maps=pd.read_csv(src/'map_results.csv'); tasks=pd.read_csv(src/'map_task_plan.csv')
    assert len(pairs)==3420 and len(maps)==3132 and len(predictions)==1566
    assert pairs.metric_defined.all() and len(aliases)==100 and aliases.image_id.nunique()==100
    pre=pairs[pairs.pair_type=='preprocessing_pair_plan.csv'].copy()
    official=pre[pre.version=='official'].copy(); current=pre[pre.version=='current'].copy()
    same=set(aliases.loc[aliases.current_bytes_identical,'image_id']); different=set(aliases.image_id)-same
    assert len(official)==1200 and len(current)==888 and len(same)==26
    fullcurrent=pd.concat([current,official[official.image_id.isin(same)]],ignore_index=True)
    datasets={'official_primary':official,'current_full_sensitivity':fullcurrent,
      'official_identical26_sensitivity':official[official.image_id.isin(same)],
      'official_differing74_sensitivity':official[official.image_id.isin(different)],
      'current_differing74_sensitivity':current}
    rows=[]; descriptive=[]; draws={}
    for scope,data in datasets.items():
      ids=sorted(data.image_id.unique()); labels=data.groupby('image_id').label.first().reindex(ids).to_numpy()
      rng=np.random.default_rng(SEED)
      sampled=np.concatenate([rng.choice(np.flatnonzero(labels==lab),(BOOT,sum(labels==lab)),replace=True) for lab in (0,1)],axis=1)
      draws[scope]=sampled
      for (method,condition),g in data.groupby(['method','condition']):
        g=g.sort_values(['image_id','seed']); assert len(g)==len(ids)*3
        assert list(g.image_id.unique())==ids
        fallback=(g.baseline_signed_fallback | g.comparison_signed_fallback).to_numpy()
        for raster in ['nearest','area_threshold','via_current_nearest']:
          for support in ['available','fallback_free']:
            keep=g.metric_defined.to_numpy() & g[f'{raster}_localization_defined'].to_numpy()
            if support=='fallback_free': keep &= ~fallback
            x=np.where(keep,g.edi.to_numpy(),np.nan).reshape(len(ids),3)
            for outcome in ['lesion_mass_delta','absolute_lesion_mass_delta']:
              y=np.where(keep,g[f'{raster}_{outcome}'].to_numpy(),np.nan).reshape(len(ids),3)
              r=float(rho_batch(x.reshape(1,-1),y.reshape(1,-1))[0])
              boots=rho_batch(x[sampled].reshape(BOOT,-1),y[sampled].reshape(BOOT,-1))
              finite=np.isfinite(boots); ci=np.nanpercentile(boots,[2.5,97.5])
              rows.append(dict(scope=scope,method=method,condition=condition,mask_raster=raster,support=support,outcome=outcome,
                n_pairs=int(keep.sum()),n_clusters=int(keep.reshape(len(ids),3).any(axis=1).sum()),resampling_clusters=len(ids),
                excluded_fallback_pairs=int(fallback.sum()) if support=='fallback_free' else 0,rho=r,ci_low=ci[0],ci_high=ci[1],
                bootstrap_defined=int(finite.sum()),bootstrap_undefined=int((~finite).sum())))
        for seed,sg in [('pooled',g),*list(g.groupby('seed'))]:
          descriptive.append(dict(scope=scope,method=method,condition=condition,seed=seed,n_pairs=len(sg),n_clusters=sg.image_id.nunique(),
            median_edi=sg.edi.median(),mean_edi=sg.edi.mean(),mean_signed_mass_change=sg.nearest_lesion_mass_delta.mean(),
            median_absolute_mass_change=sg.nearest_absolute_lesion_mass_delta.median(),
            rho_signed=spearmanr(sg.edi,sg.nearest_lesion_mass_delta).statistic,
            rho_absolute=spearmanr(sg.edi,sg.nearest_absolute_lesion_mass_delta).statistic,
            fallback_pairs=int((sg.baseline_signed_fallback|sg.comparison_signed_fallback).sum()),class_switches=int(sg.class_switch.sum())))
    results=pd.DataFrame(rows); results.to_csv(out/'localization_associations.csv',index=False)
    pd.DataFrame(descriptive).to_csv(out/'localization_descriptive_by_seed.csv',index=False)
    # Prediction association is explicitly secondary to the frozen localization endpoints.
    predrows=[]
    for (method,condition),g in official.groupby(['method','condition']):
      g=g.sort_values(['image_id','seed']); x=g.edi.to_numpy().reshape(100,3); y=g.absolute_probability_delta.to_numpy().reshape(100,3)
      boots=rho_batch(x[draws['official_primary']].reshape(BOOT,-1),y[draws['official_primary']].reshape(BOOT,-1))
      ci=np.nanpercentile(boots,[2.5,97.5])
      predrows.append(dict(method=method,condition=condition,n_pairs=300,n_clusters=100,rho=spearmanr(x.ravel(),y.ravel()).statistic,
        ci_low=ci[0],ci_high=ci[1],bootstrap_undefined=int(np.isnan(boots).sum()),class_switches=int(g.class_switch.sum())))
    pd.DataFrame(predrows).to_csv(out/'secondary_prediction_associations.csv',index=False)
    # Fixed threshold and ranking performance, each of the three models reported.
    currentpred=pd.concat([predictions[predictions.version=='current'],predictions[(predictions.version=='official') & predictions.image_id.isin(same)]])
    perf=[]
    for scope,data in [('official',predictions[predictions.version=='official']),('current_full',currentpred)]:
      for (seed,condition),g in data.groupby(['seed','condition']):
        y=g.label.to_numpy(); z=g.probability.to_numpy(); positive=y==1; ranks=rankdata(z)
        auc=(ranks[positive].sum()-positive.sum()*(positive.sum()+1)/2)/(positive.sum()*(~positive).sum())
        # AP is the sum of recall increments at each distinct score threshold, preserving ties.
        order=np.argsort(-z,kind='stable'); yy=y[order]; zz=z[order]; end=np.r_[np.flatnonzero(zz[:-1]!=zz[1:]),len(zz)-1]
        tp=np.cumsum(yy)[end]; recall=tp/positive.sum(); ap=np.sum(np.diff(np.r_[0,recall])*tp/(end+1))
        perf.append(dict(scope=scope,seed=seed,condition=condition,n=len(g),roc_auc=auc,average_precision=ap,
          brier_score=np.mean((z-y)**2),sensitivity=np.mean(z[positive]>=.5),specificity=np.mean(z[~positive]<.5),threshold=.5))
    pd.DataFrame(perf).to_csv(out/'classification_context.csv',index=False)
    coverage=tasks.merge(maps,on='task_id',validate='one_to_one').groupby(['version','seed','method','condition','label']).agg(
      maps=('task_id','size'),signed_fallback=('signed_fallback','sum'),valid_nonconstant=('valid_nonconstant','sum')).reset_index()
    coverage.to_csv(out/'map_coverage.csv',index=False)
    # Image-version differences are kept separate from preprocessing differences.
    version=pairs[pairs.pair_type=='image_version_pair_plan.csv']
    version.groupby(['method','condition','seed']).agg(n_pairs=('edi','size'),median_edi=('edi','median'),mean_edi=('edi','mean'),
      median_absolute_mass_change=('nearest_absolute_lesion_mass_delta','median'),class_switches=('class_switch','sum')).reset_index().to_csv(out/'image_version_descriptive.csv',index=False)
    primary=results[(results.scope=='official_primary') & (results.mask_raster=='nearest') & (results.support=='available')]
    free=results[(results.scope=='official_primary') & (results.mask_raster=='nearest') & (results.support=='fallback_free')]
    table='| Method | Condition | Outcome | Spearman rho | 95% image-cluster interval |\n|---|---|---|---:|---|\n'
    for r in primary.itertuples(): table+=f'| {r.method} | {r.condition} | {r.outcome} | {r.rho:.3f} | [{r.ci_low:.3f}, {r.ci_high:.3f}] |\n'
    free_table='| Method | Condition | Outcome | Pairs | rho | 95% interval |\n|---|---|---|---:|---:|---|\n'
    for r in free.itertuples(): free_table+=f'| {r.method} | {r.condition} | {r.outcome} | {r.n_pairs} | {r.rho:.3f} | [{r.ci_low:.3f}, {r.ci_high:.3f}] |\n'
    report='''# Verified localization association analysis — October 4, 2026

## Scope and interpretation

This prospective analysis uses the audited full-generation bundle and the internally dated frozen design v1.1. It is a separate dataset from the historical localization experiments and the independent running six-method HAM cohort. EDI quantifies map disagreement; lesion attribution mass measures spatial correspondence with annotations. Association does not establish causal deterioration, faithfulness, diagnostic usefulness or added value beyond prediction information.

## Primary official-reference results

Each method/condition has 300 paired observations from 100 images (50 per class) and three fixed models. Signed change is preprocessing minus original lesion mass; positive values indicate increased mass inside the lesion. Absolute change measures magnitude in either direction. The mask uses native binary >0 followed by nearest-neighbor resizing to 224.

'''+table+'''
## Signed-fallback sensitivity

Exclude a pair when either endpoint uses signed fallback. This changes support and the estimand. Signed maps normalized to nonnegative values do not retain the interpretation of exclusively positive melanoma evidence. All maps remain in the audit and primary available-support analysis.

'''+free_table+'''
## Uncertainty and support

5,000 bootstrap draws, seed 20261004, resample image IDs within true-label classes and carry all three fixed-model records together. Ranks and ties are recomputed in every draw. Intervals are 95% percentile intervals; this measures image sampling variability for these models, not variability across a population of training seeds. The same sampled image indices are shared across methods, conditions, raster and support analyses within each scope. For fallback-free analyses, resample the original image universe and then omit flagged pairs; draw-specific support can vary. Undefined bootstrap correlations are retained in the results table rather than replaced with zero. These exploratory intervals are not multiplicity-adjusted tests or a basis for method rankings.

All planned maps were nonconstant and all planned pair metrics and localization outcomes were defined. Consequently available support and common two-method support coincide exactly; a duplicated common-support result table is unnecessary. Fallback-free support is method-specific and should not be described as common support.

## Sensitivity and classification context

`localization_associations.csv` includes the full current-copy cohort (26 official computations reused by byte identity plus 74 differing copies), the 26 identical-image subset (16 melanoma, 10 non-melanoma), the 74 differing images in each version, and all three mask rasters. These are correlated sensitivities, not independent replications. Historical-copy full-frame coordinate correspondence remains an assumption; raster-path sensitivity cannot rule out unknown crops or rotations.

`localization_descriptive_by_seed.csv` reports each fixed model and pooled descriptive results. `classification_context.csv` retains all models and conditions, ROC-AUC, average precision, Brier score and unchanged 0.5 sensitivity/specificity. `secondary_prediction_associations.csv` reports exploratory EDI–absolute-probability-change associations using the same image-cluster procedure. `image_version_descriptive.csv` reports reference-to-current map comparisons separately from preprocessing comparisons. Localization is not a perturbation-faithfulness endpoint.

## Reproduction and audit limits

Run `analyze_verified_localization_v1.py --input <extracted full bundle> --output <new analysis directory>`. Source records are not modified. Source hashes, software versions and settings are in `analysis_manifest.json`. Generation review independently reproduced the prespecified 108-map compact sample and checked all exported pair-table formulas and identities. The compact sample consists of reused smoke cases; raw-array reproduction of every newly generated full-run map was not possible from this bundle. Full source arrays remain on Drive. Existing label and training-overlap limitations remain in the frozen design.
'''
    interpretation='''## Findings and defensible conclusion

In this cohort, EDI was positively associated with the magnitude of lesion-mass change for both methods and both preprocessing conditions (rho 0.465–0.513). All four primary absolute-change intervals were above zero. Excluding fallback pairs retained this pattern (GradCAM rho 0.438 and 0.458; GradCAM++ unchanged). Each fixed seed also had a positive absolute-change point estimate. This supports a measured relationship between map disagreement and spatial redistribution under these evaluated conditions.

Signed changes differ by method. GradCAM's primary associations were positive, meaning higher EDI tended to accompany increased lesion mass, rather than deterioration. After fallback exclusion, the Telea signed-change interval included zero. GradCAM++ signed-change intervals included zero in both conditions. Thus the results do not justify interpreting high EDI as worse localization or ranking explanation quality by drift.

The magnitudes deserve context: median absolute lesion-mass changes were 0.0081 and 0.0104 for GradCAM and 0.0037 and 0.0043 for GradCAM++ (about 0.37–1.04 percentage points). A rank association does not establish a practically large change. Both quantities are calculated from the same attribution maps, so some association is structurally expected; this is not independent validation of diagnostic value.

The full current-copy sensitivity retained positive absolute-change associations (rho 0.445–0.531), and both provenance-defined subsets retained positive point estimates. Alternate raster results are fully tabulated. These analyses share images and maps with the primary arm and do not count as new replications.

Secondary EDI–absolute-probability-change associations were positive (rho 0.513–0.530), with all four image-cluster intervals above zero. This contrasts with the earlier HAM factorial cohort's inconclusive associations and should be reported as cohort-dependent evidence, without replacing those results. Class switches were sparse (9 Dullrazor and 8 Telea observations among 300 model/image pairs each); these counts are shared between methods, not additional events. There is no image-grouped incremental-value model in this analysis.

Official-original ROC-AUC ranged 0.6932–0.7312, but melanoma sensitivity at 0.5 remained 0.12–0.20. The classifier context limits a clinical interpretation of localization findings.

Suggested dissertation claim: “In the verified prospective ISIC cohort, preprocessing-associated EDI was positively associated with the magnitude of lesion attribution-mass changes for both evaluated CAM implementations. Directional associations depended on method and fallback handling, supporting EDI as a measure of attribution change while limiting its interpretation as an explanation-quality indicator. Added predictive value remains untested.”

'''
    report=report.replace('## Primary official-reference results',interpretation+'## Primary official-reference results',1)
    (out/'EDI_Verified_Localization_Association_Analysis_2026-10-04.md').write_text(report)
    manifest=dict(bootstrap_draws=BOOT,bootstrap_seed=SEED,source_hashes={f:hashlib.sha256((src/f).read_bytes()).hexdigest() for f in ['pair_metrics.csv','predictions.csv','map_results.csv','map_task_plan.csv','image_version_aliases.csv']},
      script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),numpy=np.__version__,pandas=pd.__version__,primary_rows=len(primary),all_association_rows=len(results),
      bootstrap_undefined_total=int(results.bootstrap_undefined.sum()),common_available_support_identical=True)
    (out/'analysis_manifest.json').write_text(json.dumps(manifest,indent=2))
    print(primary.to_string(index=False)); print('FALLBACK FREE'); print(free.to_string(index=False))

if __name__=='__main__': main()
