"""Exploratory post-generation six-method uncertainty and joint evidence review.
Run from the conversation workspace. Requires numpy, pandas, scipy.
"""
from pathlib import Path
from itertools import combinations
import json,hashlib,zipfile,io
import numpy as np,pandas as pd
from scipy.stats import rankdata,spearmanr

OUT=Path('dissertation-repo/prospective_six_method/joint_evidence_v1');OUT.mkdir(parents=True,exist_ok=True)
SRC=Path('six-full-output');data=pd.read_csv(SRC/'paired_comparisons.csv')
METHODS=['gradcam','gradcampp','eigencam','scorecam','ig','shap'];CONDS=['dullrazor','telea'];SEEDS=[42,1337,2026]
IDS=sorted(data.image_id.unique());labels=data.groupby('image_id').label.first().reindex(IDS).to_numpy()
assert len(IDS)==40 and sum(labels==0)==sum(labels==1)==20 and len(data)==1440
index=pd.MultiIndex.from_product([IDS,SEEDS,CONDS,METHODS],names=['image_id','seed','condition','method'])
d=data.set_index(['image_id','seed','condition','method']).reindex(index)
assert len(d)==1440 and not d.baseline_task_id.isna().any()
x=d.edi.to_numpy().reshape(40,3,2,6)
common=d.all_six_defined.to_numpy().reshape(40,3,2,6);assert (common==common[:,:,:,0,None]).all()
common=common[:,:,:,0]
fallback=(d.baseline_signed_fallback|d.comparison_signed_fallback).to_numpy().reshape(40,3,2,6)
free=common&~fallback.any(axis=3)
rng=np.random.default_rng(20261004);draws=np.concatenate([rng.choice(np.flatnonzero(labels==v),(5000,20),replace=True) for v in (0,1)],axis=1)
means=[];contrasts=[];associations=[];coverage=[]
def summarize(v,balanced=False):
 boot=v[draws]
 if balanced:
  point=(np.nanmean(v[labels==0])+np.nanmean(v[labels==1]))/2
  b=(np.nanmean(boot[:,:20],axis=(1,2))+np.nanmean(boot[:,20:],axis=(1,2)))/2
 else:point=np.nanmean(v);b=np.nanmean(boot,axis=(1,2))
 finite=np.isfinite(b);ci=np.nanpercentile(b,[2.5,97.5])
 return float(point),float(ci[0]),float(ci[1]),int((~finite).sum())
def rho_batch(a,b):
 valid=np.isfinite(a)&np.isfinite(b)
 a=rankdata(np.where(valid,a,np.nan),axis=1,nan_policy='omit');b=rankdata(np.where(valid,b,np.nan),axis=1,nan_policy='omit')
 n=valid.sum(axis=1);a-=np.nanmean(a,axis=1)[:,None];b-=np.nanmean(b,axis=1)[:,None]
 den=np.sqrt(np.nansum(a*a,axis=1)*np.nansum(b*b,axis=1))
 return np.divide(np.nansum(a*b,axis=1),den,out=np.full(len(n),np.nan),where=den>0)
supports={'available':np.ones((40,3,2),bool),'common_all_six':common,'common_all_six_fallback_free':free,'common_all_six_class_balanced':common}
for ci,condition in enumerate(CONDS):
 for support,mask in supports.items():
  values=np.where(mask[:,:,ci,None],x[:,:,ci,:],np.nan);balanced=support.endswith('class_balanced')
  for mi,method in enumerate(METHODS):
   v=values[:,:,mi];point,lo,hi,undefined=summarize(v,balanced)
   means.append(dict(support=support,condition=condition,method=method,mean_edi=point,ci_low=lo,ci_high=hi,
     n_pairs=int(np.isfinite(v).sum()),n_image_clusters=int(np.isfinite(v).any(axis=1).sum()),bootstrap_undefined=undefined,
     nonmelanoma_pairs=int(np.isfinite(v[labels==0]).sum()),melanoma_pairs=int(np.isfinite(v[labels==1]).sum())))
  if support!='available':
   for ia,ib in combinations(range(6),2):
    # Same observations for both methods; no available-support subtraction.
    v=values[:,:,ia]-values[:,:,ib];point,lo,hi,undefined=summarize(v,balanced)
    contrasts.append(dict(support=support,condition=condition,method_a=METHODS[ia],method_b=METHODS[ib],difference_a_minus_b=point,
      ci_low=lo,ci_high=hi,n_pairs=int(np.isfinite(v).sum()),n_image_clusters=int(np.isfinite(v).any(axis=1).sum()),bootstrap_undefined=undefined))
 for mi,method in enumerate(METHODS):
  for lab in [0,1]:
   g=data[(data.condition==condition)&(data.method==method)&(data.label==lab)]
   coverage.append(dict(condition=condition,method=method,label=lab,planned_pairs=len(g),defined_pairs=int(g.metric_defined.sum()),
     common_pairs=int(g.all_six_defined.sum()),mean_edi_available=g.edi.mean()))
  # Secondary exploratory association; completeness/support masks retained.
  prob=d.absolute_probability_change.to_numpy().reshape(40,3,2,6)[:,:,ci,mi]
  for support in ['available','common_all_six','common_all_six_fallback_free']:
   a=np.where(supports[support][:,:,ci],x[:,:,ci,mi],np.nan);b=np.where(np.isfinite(a),prob,np.nan)
   point=rho_batch(a.reshape(1,-1),b.reshape(1,-1))[0]
   boots=rho_batch(a[draws].reshape(5000,-1),b[draws].reshape(5000,-1));lo,hi=np.nanpercentile(boots,[2.5,97.5])
   associations.append(dict(support=support,method=method,condition=condition,rho=point,ci_low=lo,ci_high=hi,
     n_pairs=int(np.isfinite(a).sum()),n_image_clusters=int(np.isfinite(a).any(axis=1).sum()),bootstrap_undefined=int(np.isnan(boots).sum())))
means=pd.DataFrame(means);contrasts=pd.DataFrame(contrasts);associations=pd.DataFrame(associations)
means.to_csv(OUT/'six_method_mean_uncertainty.csv',index=False);contrasts.to_csv(OUT/'six_method_paired_contrasts.csv',index=False)
associations.to_csv(OUT/'six_method_prediction_associations.csv',index=False);pd.DataFrame(coverage).to_csv(OUT/'six_method_class_coverage.csv',index=False)
data.groupby(['seed','condition','method']).agg(planned_pairs=('edi','size'),defined_pairs=('metric_defined','sum'),mean_edi_available=('edi','mean'),
  mean_absolute_probability_change=('absolute_probability_change','mean')).reset_index().to_csv(OUT/'six_method_seed_descriptive.csv',index=False)
# Verify against the supplied descriptive means and a separate bootstrap loop.
original=pd.read_csv(SRC/'descriptive_summary.csv')
for r in original.itertuples():
 for support,col in [('available','mean_edi_available'),('common_all_six','mean_edi_common')]:
  point=means[(means.support==support)&(means.condition==r.condition)&(means.method==r.method)].mean_edi.iloc[0]
  assert abs(point-getattr(r,col))<1e-15
v=np.where(common[:,:,0],x[:,:,0,4]-x[:,:,0,1],np.nan)
reference=np.array([np.nanmean(v[ids]) for ids in draws])
expected=contrasts[(contrasts.support=='common_all_six')&(contrasts.condition=='dullrazor')&(contrasts.method_a=='gradcampp')&(contrasts.method_b=='ig')].iloc[0]
np.testing.assert_allclose([-np.nanmean(v),*np.percentile(-reference,[2.5,97.5])],[expected.difference_a_minus_b,expected.ci_low,expected.ci_high],atol=1e-14,rtol=0)
# Preserve previously completed training-variability evidence instead of recomputing a different estimand.
with zipfile.ZipFile('dissertation-repo/EDI_Matched_Initialization_Uncertainty_v1 (1).zip') as z:
 for name in ['image_clustered_contrasts.csv','metadata.json']: (OUT/('matched_initialization_'+name)).write_bytes(z.read(name))
local=Path('dissertation-repo/prospective_six_method/localization_analysis_v1')
for name in ['localization_associations.csv','secondary_prediction_associations.csv']:
 (OUT/('isic_'+name)).write_bytes((local/name).read_bytes())
manifest=dict(analysis_type='exploratory post-generation analysis specified after outcomes were available; not preregistered',bootstrap_draws=5000,
 seed=20261004,resampling='40 image clusters within true-label classes (20/20); all fixed model/method/condition records carried together',
 common_support='same image, seed and preprocessing condition; all six EDI values defined',fallback_free='common support with no signed fallback at any method endpoint',
 balanced_sensitivity='equal weight to class-specific common-support means',seed_population_inference=False,multiplicity_adjusted=False,
 script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_hashes={name:hashlib.sha256((SRC/name).read_bytes()).hexdigest() for name in ['paired_comparisons.csv','map_diagnostics.csv','descriptive_summary.csv']},
 verification='All exported mean estimates reconcile; one contrast independently replayed for 5000 bootstrap draws; rank correlations recompute ties in each draw',
 undefined_bootstraps_total=int(means.bootstrap_undefined.sum()+contrasts.bootstrap_undefined.sum()+associations.bootstrap_undefined.sum()))
(OUT/'analysis_manifest.json').write_text(json.dumps(manifest,indent=2))
print(means[means.support=='common_all_six'].to_string(index=False));print('PRIMARY EXPLORATORY PREDICTION ASSOCIATIONS');print(associations[associations.support=='available'].to_string(index=False))
