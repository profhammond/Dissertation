# Joint EDI evidence review — October 4, 2026

## Conclusion supported by the verified evidence

Under the evaluated comparison conditions, EDI quantifies attribution-map disagreement whose relationships with preprocessing, method, training variability, prediction change and lesion localization can be measured. Those relationships depend on the implementation, comparison protocol and evaluated cohort. EDI has not been established as an explanation-quality indicator or as providing added predictive value beyond prediction information.

The prospective evidence is stronger than the historical aggregate rankings because the new cohorts preserve endpoint maps, explicit target/settings identity and verified numerical reproduction. They remain limited pilots. They do not repair unresolved identities in the historical corpus.

## New six-method analysis

This is an **exploratory post-generation analysis**, specified after outcomes were available, not a preregistered confirmatory test. All 15 method-pair contrasts are provided for each condition rather than selecting contrasts by outcome.

Use 5,000 image-cluster bootstrap draws, seed 20261004, resampling the original 40 images within the two label classes (20 per class). Each sampled image carries all three fixed-model, method and condition records. Shared draws preserve pairing across contrasts. Means are calculated over defined observations in each draw; missing maps are never assigned zero EDI. Ranks and ties are recomputed for prediction correlations. Undefined draws are recorded; none occurred here. Intervals are 95% percentile intervals, without multiplicity adjustment or population-seed inference.

Common six-method support has 97 model/image pairs per condition, from 34 images, including 60 melanoma and 37 non-melanoma observations. The resampling universe remains the original 40 images; sampled images without any defined common records contribute no observations. Fallback-free common support has 93 pairs from 32 images, including 60 melanoma and 33 non-melanoma observations. Class-balanced sensitivity gives equal weight to each class's mean on common support; it does not recover missing ScoreCAM outcomes or restore the original balanced cohort.

### Common-support mean EDI

| Implementation | Dullrazor mean [95% interval] | Telea mean [95% interval] |
|---|---|---|
| GradCAM | 0.131 [0.093, 0.172] | 0.133 [0.096, 0.173] |
| GradCAM++ approximation | 0.113 [0.081, 0.145] | 0.120 [0.089, 0.153] |
| EigenCAM | 0.144 [0.086, 0.209] | 0.147 [0.088, 0.212] |
| ScoreCAM | 0.127 [0.091, 0.168] | 0.139 [0.098, 0.183] |
| Integrated Gradients | 0.293 [0.255, 0.332] | 0.321 [0.280, 0.361] |
| SHAP Partition | 0.219 [0.189, 0.250] | 0.227 [0.197, 0.258] |

These are differences in map disagreement, not quality rankings. Each pairwise contrast among the four CAM implementations has an interval containing zero on common support. This does not prove equivalence. IG and SHAP have larger mean EDI than each CAM implementation; the exploratory paired intervals for those contrasts exclude zero in both conditions. IG also exceeds SHAP: difference 0.0745 [0.0478, 0.1005] for Dullrazor and 0.0941 [0.0658, 0.1225] for Telea. These directions persist under fallback-free and class-balanced common-support analyses. No general ordering beyond these evaluated implementations is justified.

Coverage remains part of the result: all 33 constant maps and 46 undefined pairs are ScoreCAM/non-melanoma outcomes under the declared positive-clipped black-reference variant. Available-support means and class-specific coverage are also supplied. Complete-case selection is nonrandom and changes the estimand.

## Prediction behavior

The prospective HAM six-method study measures EDI against absolute melanoma-probability change for fixed baseline models. Available-support GradCAM associations are rho 0.342 [0.138, 0.509] for Dullrazor and 0.259 [0.020, 0.460] for Telea. ScoreCAM associations are positive on its smaller available support; IG's Dullrazor interval is above zero, while its Telea interval includes zero. Available-support GradCAM++ approximation, EigenCAM and SHAP intervals include zero. On common support, GradCAM++ approximation and IG also have positive intervals in both conditions. This support dependence is material; do not summarize it as a universal EDI–prediction relationship or choose the more favorable support after examining results.

The prospective verified ISIC study reports CAM probability-change rho 0.513–0.530, with image-cluster intervals above zero. The earlier factorial analysis retains its separate finding that none of its 20 association intervals excluded zero. The six-method HAM study reuses the earlier baseline model set and locked HAM cohort, and uses a fresh, explicitly documented attribution/normalization/metric protocol. It is not an independent replication of the earlier factorial evidence and should not be presented as a replacement or attributed solely to a different cohort. Differences may reflect comparison type, implementation or normalization/metric settings. The later matched-initialization models form another distinct model set.

These are associations. Neither the HAM nor ISIC analysis includes an image-grouped validated outcome model comparing prediction information alone against prediction information plus EDI. Incremental-value claims therefore remain untested.

## Training variability

The existing later matched-initialization contrasts are preserved rather than recalculated under a new estimator. All 720 saved maps and 2,160 metrics now have verified current-asset numerical reproduction.

| Method | Dullrazor excess over baseline cross-seed reference | Telea excess over reference |
|---|---|---|
| GradCAM | 0.159 [0.107, 0.216] | 0.166 [0.111, 0.224] |
| GradCAM++ (later-study implementation) | −0.046 [−0.099, 0.009] | 0.006 [−0.039, 0.052] |

These are paired per-image mean contrasts for the evaluated models, using the earlier 5,000-draw image bootstrap (seed 20261005, unstratified because labels were absent from that analysis). They show method-dependent separation relative to an empirical training reference. They do not estimate a causal fraction of drift or a population of training seeds. Recorded initialization digests were not recomputed from initial-weight arrays, and historical attribution-generating model identity remains limited. Do not numerically compare these EDI means with the prospective six-method values as though implementation and normalization settings were identical.

## Localization and explanation quality

The verified prospective ISIC cohort has 100 images, three fixed models, two CAM implementations and audited official image/mask correspondence. EDI is positively associated with absolute lesion-mass change (rho 0.465–0.513); all four primary intervals are above zero. Fallback-free analysis retains the magnitude relationship. Median absolute mass changes are approximately 0.37–1.04 percentage points, so a rank association need not imply a large practical change.

Signed changes do not support a general deterioration interpretation: GradCAM's primary associations are positive (increased lesion mass), its Telea signed interval includes zero after fallback exclusion, and GradCAM++ approximation's signed intervals include zero. Both EDI and localization change are computed from the same maps, so this is not independent evidence of clinical value. Official-original classifier ROC-AUC is 0.6932–0.7312, with low sensitivity (0.12–0.20) at the unchanged 0.5 threshold.

This new stage measures localization, not perturbation faithfulness. Existing deletion/insertion studies retain their previous limitations and are not strengthened merely by generating new localization maps. Greater or lower lesion mass alone does not establish faithful diagnostic features.

## Evidence boundary and next decision

The research proposition is now supported at the level of measured, conditional relationships. A defensible statement is: “Verified experiments show that attribution drift is method-dependent and can relate to prediction change and the magnitude of lesion-localization change. Its direction and interpretation depend on comparison conditions and training variability; lower EDI alone does not establish better explanations.”

The remaining scientific gap is added value, which would require a defined independent outcome, a prediction-information comparator and image-grouped validation. No new large experiment is required to report the current verified findings. Whether to pursue that gap is a separate research-design decision; it should not be filled with an unsupported claim.

No dissertation source changes were made. The analytical evidence is ready for a coordinated methods/results/discussion update, one copy/paste edit at a time against current verified source.

## Reproducibility

`analyze_joint_evidence_v1.py` generates the new six-method tables, retains the completed matched-initialization and ISIC tables, and writes source/settings hashes to `analysis_manifest.json`. The workspace layout includes extracted `six-full-output`, the earlier matched uncertainty ZIP and the completed localization analysis folder. Every supplied six-method mean reconciles with the generation summary. One paired contrast was independently replayed for all 5,000 bootstrap draws. Results are auditable statistical outputs rather than additional attribution generation. No source experiment records were modified.
