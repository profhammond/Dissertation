# Chapter 5 matched-initialization provenance audit

Numerical results PASS. All six displayed means and the four difference statements agree with independent recalculation from the recovered 2,160-row parquet. Grad-CAM ratios reproduce as 2.74 and 2.82. No numerical revision is required.

The notebook comparison-plan algorithm reproduces all 27 pair identifiers and model/seed pairings. Every pair/method has 40 images; there are no duplicate comparison keys or nonfinite required metrics. Maximum primary EDI formula error: 2.22e-16.

All 720 JSON diagnostic records report valid, nonconstant maps with finite map pixels. Fallback counts match the dissertation: 44 Grad-CAM, 24 Grad-CAM++, 68 total. Both endpoints of every comparison resolve to corresponding diagnostic metadata.

Evidence still needed: original model completion records (models/*_seed*/DONE.json), including initialization_digest. The saved notebook reports nine completed models and one initialization digest per seed, but those completion records are absent from the recovered diagnostics ZIP. Consequently this audit does not independently certify initial weights or training completion. The diagnostics describe maps; map arrays are not present and their metrics have not been recomputed here.

No rerun or retraining is needed to resolve this evidence gap. Recover the nine DONE.json files, pair_plan.csv, and final_status.json from the existing run:
/content/drive/MyDrive/Dissertation/edi_matched_initialization_training/edi_matched_initialization_training_ham_r224_v1/

The notebook reports its full output ZIP as:
/content/drive/MyDrive/Dissertation/edi_matched_initialization_training/edi_matched_initialization_training_ham_r224_v1_outputs.zip
Prefer the small completion records if the full bundle contains large model files.

Run reproduce_audit.py after installing pandas, numpy, pyarrow. Original inputs, source hashes, recreated means and contrasts, and machine-readable findings are included. Analyses remain separate from the principal dissertation corpus; contrasts remain descriptive.
